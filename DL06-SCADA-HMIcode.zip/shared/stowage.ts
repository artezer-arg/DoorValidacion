import type {HmiState,Sequence} from './types';
export type Paint = 'EMPTY'|'PENDING'|'CURRENT'|'ERROR'|'COMPLETE';
export interface DollyProgress {number:number;assigned:number;completed:number;paint:Paint;}
export interface RackCell {level:Sequence['dolly_level'];column:number;sequence:Sequence|null;paint:Paint;}
/** Only a persisted COMPLETE sequence represents physically confirmed placement. */
export function activeDestination(state:HmiState):Sequence|null {
 if(['SET_COMPLETE','BLOCK_PRINTING','TRUCK_COMPLETE'].includes(state.phase))return null;
 if(state.printJobs.some(j=>j.status==='FAILED'||j.status==='PENDING'))return null;
 return state.current?.status!=='COMPLETE'?state.current:null;
}
export function dollyProgress(state:HmiState):DollyProgress[]{
 const active=activeDestination(state);
 return Array.from({length:8},(_,i)=>{
 const number=i+1,assigned=state.sequences.filter(s=>s.dolly_number===number),completed=assigned.filter(s=>s.status==='COMPLETE').length;
 const current=active?.dolly_number===number;
 const fullAssignment=state.source.mode!=='SQL'||new Set(assigned.map(r=>r.load_index)).size>=(state.dollyLayout.mode==='PAIRED'?6:3);
 const paint:Paint=assigned.length>0&&fullAssignment&&completed===assigned.length?'COMPLETE':current?(state.phase==='ERROR'||state.phase==='PLC_TIMEOUT'?'ERROR':'CURRENT'):completed>0?'CURRENT':assigned.length?'PENDING':'EMPTY';
 return {number,assigned:assigned.length,completed,paint};
 });
}
export function rackCells(state:HmiState,dolly:number):RackCell[]{
 const active=activeDestination(state);
 return (['TOP','BOTTOM'] as const).flatMap(level=>Array.from({length:6},(_,i)=>{
 const column=i+1,sequence=state.sequences.find(s=>s.dolly_number===dolly&&s.dolly_level===level&&s.dolly_column===column)??null;
 // Explicitly require a sequence and active target; undefined IDs must never match.
 const current=sequence!==null&&active!==null&&sequence.id===active.id;
 const paint:Paint=sequence?.status==='COMPLETE'?'COMPLETE':current?(state.phase==='ERROR'||state.phase==='PLC_TIMEOUT'?'ERROR':'CURRENT'):sequence?'PENDING':'EMPTY';
 return {level,column,sequence,paint};
 }));
}
export const paintClass:Record<Paint,string>={EMPTY:'',PENDING:'planned',CURRENT:'current',ERROR:'rejected',COMPLETE:'loaded'};
