export const defaultLayout = { mode: 'STANDARD', showPair: false, routes: { 'FR-RH': { dolly: 1, level: 'TOP' }, 'FR-LH': { dolly: 2, level: 'TOP' }, 'RR-LH': { dolly: 1, level: 'BOTTOM' }, 'RR-RH': { dolly: 2, level: 'BOTTOM' } } };
export function validateLayout(value) {
    const v = value;
    if (!v || !['STANDARD', 'PAIRED'].includes(v.mode) || typeof v.showPair !== 'boolean')
        throw new Error('Distribución inválida');
    const occupied = new Set();
    for (const key of Object.keys(defaultLayout.routes)) {
        const r = v.routes?.[key];
        if (!r || ![1, 2].includes(r.dolly) || !['TOP', 'BOTTOM'].includes(r.level))
            throw new Error('Destino inválido para ' + key);
        const slot = r.dolly + '-' + r.level;
        if (occupied.has(slot))
            throw new Error('Dos tipos de panel no pueden ocupar el mismo nivel del mismo dolly');
        occupied.add(slot);
    }
    return { mode: v.mode, showPair: v.showPair, routes: JSON.parse(JSON.stringify(v.routes)) };
}
export function panelDestination(index, position, hand, layout) {
    if (layout.mode === 'STANDARD')
        return { dollyNumber: Math.floor((index - 1) / 3) + 1, dollyLevel: position === 'FR' ? 'TOP' : 'BOTTOM', dollyColumn: ((index - 1) % 3) * 2 + (hand === 'LH' ? 1 : 2) };
    const route = layout.routes[`${position}-${hand}`];
    return { dollyNumber: Math.floor((index - 1) / 6) * 2 + route.dolly, dollyLevel: route.level, dollyColumn: (index - 1) % 6 + 1 };
}
