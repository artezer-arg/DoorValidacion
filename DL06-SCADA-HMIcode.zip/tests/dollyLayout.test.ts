import {test} from 'node:test';
import assert from 'node:assert/strict';
import {defaultLayout,panelDestination,validateLayout} from '../server/dollyLayout.js';
import {openDb} from '../server/db.js';
import {FsmService} from '../server/fsmService.js';
import {PlcService} from '../server/plcService.js';
import {PrinterService} from '../server/printerService.js';
test('paired routing packs 24 vehicles into eight dollys without duplicate cells',()=>{
 const layout={...structuredClone(defaultLayout),mode:'PAIRED' as const,showPair:true};const used=new Set<string>();
 for(let n=1;n<=24;n++)for(const position of ['FR','RR'] as const)for(const hand of ['LH','RH'] as const){const d=panelDestination(n,position,hand,layout);const key=`${d.dollyNumber}-${d.dollyLevel}-${d.dollyColumn}`;assert.ok(!used.has(key));used.add(key);assert.ok(d.dollyNumber<=8);}
 assert.equal(used.size,96);assert.deepEqual(panelDestination(6,'FR','RH',layout),{dollyNumber:1,dollyLevel:'TOP',dollyColumn:6});assert.deepEqual(panelDestination(7,'RR','RH',layout),{dollyNumber:4,dollyLevel:'BOTTOM',dollyColumn:1});
 const invalid=structuredClone(layout);invalid.routes['FR-LH']=invalid.routes['FR-RH'];assert.throws(()=>validateLayout(invalid),/mismo nivel/);
});
test('routing configuration persists and view can change during scanning while mapping is locked',async()=>{
 const db=openDb(':memory:');const fsm=new FsmService(db,new PlcService(),new PrinterService());fsm.configure({latencyMs:1,timeoutMs:100});
 fsm.configureLayout({...structuredClone(defaultLayout),mode:'PAIRED',showPair:true});assert.equal(new FsmService(db,new PlcService(),new PrinterService()).state().dollyLayout.showPair,true);
 await fsm.scan(fsm.state().current!.expected_panel_code);assert.throws(()=>fsm.configureLayout({...defaultLayout,mode:'STANDARD'}),/bloqueada/);fsm.configureLayout({...fsm.layout(),showPair:false});assert.equal(fsm.state().dollyLayout.showPair,false);db.close();
});
