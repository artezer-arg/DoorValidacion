import {defaultLayout} from '../server/dollyLayout.js';
import {test} from 'node:test';import assert from 'node:assert/strict';import {buildSourcePlan,validateSelection} from '../server/sourcePlanner.js';import type {OrderRow,BomRow} from '../server/sourceTypes.js';
import {createElement} from 'react';import {renderToStaticMarkup} from 'react-dom/server';import {HeroObjective} from '../frontend/src/components/HeroObjective.js';
import {openDb} from '../server/db.js';import {FsmService} from '../server/fsmService.js';import {PlcService} from '../server/plcService.js';import {PrinterService} from '../server/printerService.js';import {formatArmrestBarcode} from '../server/armrestBarcode.js';import {dollyProgress,rackCells} from '../shared/stowage.js';
const selection={date:'2026-09-18',start:842,end:865};
const bom:BomRow[]=[{id:615,suffix:'M3CU',sd:'D3L'},{id:616,suffix:'M3CU',sd:'A3L'},{id:617,suffix:'M3CU',sd:'GDC'},{id:618,suffix:'M1GR',sd:'D1H'},{id:619,suffix:'M1GR',sd:'A1H'},{id:620,suffix:'M3GR',sd:'D3H'},{id:621,suffix:'M3GR',sd:'A3H'},{id:622,suffix:'M3GR',sd:'GDC'}];
function orders():OrderRow[]{const rows:OrderRow[]=[];for(let i=0;i<24;i++){const short=i%3===2,suffix=short?'M1GR':i%2?'M3GR':'M3CU',sd=short?'D1H':i%2?'D3H':'D3L';for(const [order,hand,position] of [[1,'LH','FR'],[2,'LH','RR'],[3,'RH','FR'],[4,'RH','RR']] as const){if(short&&position==='RR')continue;rows.push({id:10000+i*4+order,clientOrderId:335+i,sequence:842+i,date:selection.date,suffix,sd,reference:`REF-${i}-${order}`,hand,position,order});}}return rows;}

test('SQL targets import and advance 80 panels / 24 vehicles, exact rack cells and four six-vehicle labels',async()=>{
 process.env.TEST_MODE='false';const db=openDb(':memory:');const printer=new PrinterService();const labels:string[]=[];printer.print=async(_id,zpl)=>{labels.push(zpl);};const fsm=new FsmService(db,new PlcService(),printer);fsm.configure({latencyMs:1,timeoutMs:50});
 fsm.configureLayout({...defaultLayout,mode:'STANDARD',showPair:false});await fsm.loadSource(async()=>buildSourcePlan(selection,orders(),bom),60);
 assert.equal(fsm.state().source.mode,'SQL');assert.equal(fsm.state().current!.source_order_id,10001);assert.equal(fsm.state().current!.expected_panel_code,'0842;LH;FR;D3L');assert.equal(fsm.state().panelProgress.total,80);assert.ok(fsm.state().sequences.every(s=>s.garnish_required===(s.position==='RR'&&s.expected_garnish_code!=='NO_APLICA'?1:0)));assert.equal(db.prepare('SELECT count(*) n FROM trucks').get()!.n,2);
 let completed=0;
 while(fsm.state().current){const s=fsm.state().current!;
 await fsm.scan(s.expected_panel_code);await fsm.scan(formatArmrestBarcode(s.expected_armrest_sd!,s.position,s.hand,Date.now()-61*60000));
 if(s.garnish_required)await fsm.scan(s.expected_garnish_code);
 completed++;assert.equal(fsm.state().panelProgress.completed,completed);
 if(completed===1){assert.equal(fsm.state().truck.completed_sets,0);await assert.rejects(()=>fsm.loadSource(async()=>buildSourcePlan(selection,orders(),bom),60),/antes de iniciar/);}
 assert.equal(rackCells(fsm.state(),s.dolly_number).find(c=>c.level===s.dolly_level&&c.column===s.dolly_column)!.paint,'COMPLETE');
 }
 assert.equal(fsm.state().phase,'TRUCK_COMPLETE');assert.equal(fsm.state().truck.completed_sets,24);assert.equal(labels.length,4);assert.match(labels[0],/847/);assert.doesNotMatch(labels[0],/\^FD848 /);assert.ok(dollyProgress(fsm.state()).every(d=>d.paint==='COMPLETE'));
 assert.equal(db.prepare('SELECT count(*) n FROM sets WHERE garnish_skipped=1 AND garnish_plc_ok=0').get()!.n,48);
 const restarted=new FsmService(db,new PlcService(),printer);assert.equal(restarted.state().source.mode,'SQL');assert.equal(restarted.state().panelProgress.completed,80);assert.throws(()=>restarted.reset(),/programa SQL/);db.close();
});
test('failed SQL read preserves current target; in-flight import blocks concurrent scans',async()=>{
 process.env.TEST_MODE='true';const db=openDb(':memory:');const fsm=new FsmService(db,new PlcService(),new PrinterService());const previous=fsm.state().current!.id;
 await assert.rejects(()=>fsm.loadSource(async()=>{throw new Error('offline');},60),/offline/);assert.equal(fsm.state().current!.id,previous);assert.equal(fsm.state().busy,false);
 let release!:(value:ReturnType<typeof buildSourcePlan>)=>void;const pending=fsm.loadSource(()=>new Promise(resolve=>{release=resolve;}),60);await fsm.scan('P');assert.equal(fsm.state().phase,'WAITING_PANEL');release(buildSourcePlan(selection,orders(),bom));await pending;assert.equal(fsm.state().current!.sequence_number,842);db.close();
});

test('screenshot-shaped SQL: 88 rows, date 2026-09-18, nonconsecutive Orden and D3L LH FR first target',async()=>{
 const rows:OrderRow[]=[];for(let i=0;i<24;i++){for(const [order,hand,position] of [[1,'LH','FR'],[3,'LH','RR'],[5,'RH','FR'],[8,'RH','RR']] as const){if([2,8,14,20].includes(i)&&position==='RR')continue;rows.push({id:i===0&&order===1?6971:8000+i*10+order,clientOrderId:335+i,sequence:i+1,date:'2026-09-18',suffix:'M3CU',sd:'D3L',reference:'67620-0KM80-C4',order,hand,position});}}
 assert.equal(rows.length,88);const plan=buildSourcePlan({date:'2026-09-18',start:1,end:24},rows,bom);process.env.TEST_MODE='true';const db=openDb(':memory:');const fsm=new FsmService(db,new PlcService(),new PrinterService());fsm.configureLayout({...defaultLayout,mode:'STANDARD',showPair:false});await fsm.loadSource(async()=>plan,60);const current=fsm.state().current!;assert.equal(current.source_order_id,6971);assert.equal(current.sequence_number,1);assert.equal(current.model,'D3L');assert.equal(current.hand,'LH');assert.equal(current.position,'FR');assert.equal(current.reference,'67620-0KM80-C4');assert.equal(fsm.state().panelProgress.total,88);db.close();
});

test('hero labels demonstration versus SQL and renders imported SD, source order and reference',async()=>{
 process.env.TEST_MODE='true';const db=openDb(':memory:');const fsm=new FsmService(db,new PlcService(),new PrinterService());assert.match(renderToStaticMarkup(createElement(HeroObjective,{state:fsm.state()})),/DATOS DEMO/);fsm.configureLayout({...defaultLayout,mode:'STANDARD',showPair:false});await fsm.loadSource(async()=>buildSourcePlan(selection,orders(),bom),60);const html=renderToStaticMarkup(createElement(HeroObjective,{state:fsm.state()}));assert.match(html,/DATOS SQL DL06/);assert.match(html,/D3L/);assert.match(html,/ORDEN 10001/);assert.match(html,/REF-0-1/);assert.doesNotMatch(html,/\(CUERO\)|P3A|SEQ-842/);db.close();
});

test('first sequence date anchors loading; later vehicle dates may differ and persist through import',async()=>{
 const rows=orders().map(row=>({...row,date:row.sequence>=864?'2026-09-19':row.date}));const plan=buildSourcePlan(selection,rows,bom);assert.equal(plan.vehicles[22].panels[0].date,'2026-09-19');process.env.TEST_MODE='true';const db=openDb(':memory:');const fsm=new FsmService(db,new PlcService(),new PrinterService());fsm.configureLayout({...defaultLayout,mode:'STANDARD',showPair:false});await fsm.loadSource(async()=>plan,60);assert.equal(fsm.state().source.date,'2026-09-18');assert.equal(fsm.state().current!.sequence_number,842);assert.equal(fsm.state().panelProgress.total,80);
 assert.throws(()=>buildSourcePlan(selection,rows.map(r=>r.sequence===842?{...r,date:'2026-09-19'}:r),bom),/Primera secuencia/);
 assert.throws(()=>buildSourcePlan(selection,rows.filter(r=>r.sequence!==865),bom),/865/);db.close();
});

test('activate SQL from an already started demo preserves completed sets and partial cycle, then exposes real scan target',async()=>{
 process.env.TEST_MODE='true';const db=openDb(':memory:');const printer=new PrinterService();printer.print=async()=>{};const fsm=new FsmService(db,new PlcService(),printer);fsm.configure({latencyMs:1,timeoutMs:30});await fsm.scan('DEMO-P');await fsm.scan('DEMO-A');await fsm.scan('DEMO-G');await fsm.scan('PARTIAL-DEMO-P');const demoId=fsm.state().truck.id;assert.equal(fsm.state().phase,'WAITING_ARMREST');assert.equal(fsm.state().truck.completed_sets,1);
 await fsm.loadSource(async()=>buildSourcePlan(selection,orders(),bom),60);const state=fsm.state();assert.equal(state.source.mode,'SQL');assert.equal(state.phase,'WAITING_PANEL');assert.equal(state.current!.model,'D3L');assert.equal(state.current!.hand,'LH');assert.equal(state.current!.position,'FR');assert.equal(state.current!.source_order_id,10001);assert.equal(state.truck.completed_sets,0);assert.equal(db.prepare('SELECT count(*) n FROM sets WHERE truck_id=?').get(demoId)!.n,1);const archived=JSON.parse(String(db.prepare('SELECT payload FROM runtime_archives WHERE truck_id=?').get(demoId)!.payload));assert.equal(archived.phase,'WAITING_ARMREST');assert.equal(archived.cycle.panel_barcode,'PARTIAL-DEMO-P');const restarted=new FsmService(db,new PlcService(),printer);assert.equal(restarted.state().source.mode,'SQL');assert.equal(restarted.state().current!.source_order_id,10001);db.close();
});
test('failed activation from a started demo leaves its cycle and traceability intact',async()=>{
 process.env.TEST_MODE='true';const db=openDb(':memory:');const fsm=new FsmService(db,new PlcService(),new PrinterService());fsm.configure({latencyMs:1,timeoutMs:30});await fsm.scan('DEMO-P');const previous=fsm.state();await assert.rejects(()=>fsm.loadSource(async()=>{throw new Error('SQL offline');},60),/SQL offline/);assert.equal(fsm.state().source.mode,'DEMO');assert.equal(fsm.state().phase,'WAITING_ARMREST');assert.deepEqual(fsm.state().cycle,previous.cycle);assert.equal(db.prepare('SELECT count(*) n FROM runtime_archives').get()!.n,0);assert.equal(db.prepare('SELECT count(*) n FROM trucks').get()!.n,1);db.close();
});

test('configured paired SQL import uses six vehicles per pair and renders both racks',async()=>{
 const {defaultLayout}=await import('../server/dollyLayout.js');const {ValidationColumns}=await import('../frontend/src/components/ValidationColumns.js');
 const db=openDb(':memory:');const printer=new PrinterService();printer.print=async()=>{};const fsm=new FsmService(db,new PlcService(),printer);
 fsm.configureLayout({...structuredClone(defaultLayout),mode:'PAIRED',showPair:true});await fsm.loadSource(async()=>buildSourcePlan(selection,orders(),bom),60);
 const rows=fsm.state().sequences;
 assert.equal(rows.find(s=>s.sequence_number===842&&s.position==='FR'&&s.hand==='RH')!.dolly_number,1);
 assert.equal(rows.find(s=>s.sequence_number===842&&s.position==='FR'&&s.hand==='LH')!.dolly_number,2);
 assert.equal(rows.find(s=>s.sequence_number===847&&s.position==='FR'&&s.hand==='RH')!.dolly_column,6);
 assert.equal(rows.find(s=>s.sequence_number===848&&s.position==='FR'&&s.hand==='RH')!.dolly_number,3);
 const markup=renderToStaticMarkup(createElement(ValidationColumns,{state:fsm.state(),scan:()=>{},enabled:true,view:'dolly'}));assert.match(markup,/DOLLY 1/);assert.match(markup,/DOLLY 2/);assert.equal((markup.match(/data-armrest-slot=/g)??[]).length,24);db.close();
});
