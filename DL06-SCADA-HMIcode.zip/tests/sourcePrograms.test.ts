import {readFileSync} from 'node:fs';
import {test} from 'node:test';import assert from 'node:assert/strict';import {SqlServerSource} from '../server/sqlServerSource.js';
test('program catalog reads dates from DL06 D% without filtering by today or reading BOM',async()=>{
 const source=new SqlServerSource();let query='';const rows=[{date:'2026-09-18',panels:88,vehicles:24,firstSequence:1,lastSequence:24}];
 // Replace only the SQL transport; exercise production catalog query selection and result mapping.
 (source as unknown as {pool:()=>Promise<unknown>}).pool=async()=>({request:()=>({query:async(sql:string)=>{query=sql;return {recordset:rows};}})});
 assert.deepEqual(await source.programs(),rows);assert.match(query,/Puesto = 'DL06' AND SD LIKE 'D%'/);assert.match(query,/COUNT\(DISTINCT Secuencia\)/);assert.doesNotMatch(query,/@fecha|GETDATE|BOM_Suffix|TOP/);
});

test('SQL date predicate restricts first sequence only and BOM uses the exact selected rows',()=>{
 const sql=readFileSync('sql/leer_programa_dl01.sql','utf8');assert.match(sql,/Secuencia<>@desde OR \(Fecha_Secuencia>=@fecha/);assert.match(sql,/ID_OrdenProduccion>=@anchor/);assert.match(sql,/ID_OrdenProduccion<@nextProgram/);assert.match(sql,/SELECT DISTINCT suffix FROM #DL06Selected/);assert.doesNotMatch(sql,/TOP/);
});
