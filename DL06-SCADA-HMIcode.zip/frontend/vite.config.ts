import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({root:'frontend',plugins:[react()],build:{outDir:'../public',emptyOutDir:true},server:{proxy:{'/socket.io':{target:'http://localhost:3002',ws:true},'/api':'http://localhost:3002'}}});