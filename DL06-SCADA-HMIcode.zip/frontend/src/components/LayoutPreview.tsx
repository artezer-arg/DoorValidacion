import React from 'react';
import type {DollyLayout,PanelKey} from '../../../shared/dollyLayout';
const keys:PanelKey[]=['FR-RH','FR-LH','RR-LH','RR-RH'];
/** Illustrative positions, never production status. */
export function LayoutPreview({layout,allowed}:{layout:DollyLayout;allowed?:string[]}){
 function panel(dolly:number,level:'TOP'|'BOTTOM',column:number):PanelKey|undefined{
  if(layout.mode==='STANDARD')return `${level==='TOP'?'FR':'RR'}-${column%2===0?'LH':'RH'}` as PanelKey;
  return keys.find(k=>layout.routes[k].dolly===dolly&&layout.routes[k].level===level);
 }
 return <div className="layout-preview"><div className="preview-caption"><strong>{allowed?'Paneles de este puesto':'Vista previa de la distribución'}</strong><span>Ejemplo · sin estados de producción</span></div><div className="mini-dolly-pair">{[1,2].map(dolly=><div className="mini-dolly" key={dolly} aria-label={`Vista previa dolly ${dolly}`}><div className="mini-dolly-heading"><b>DOLLY {dolly}</b><span>{layout.mode==='PAIRED'?'6 vehículos por par':'3 vehículos por dolly'}</span></div><div className="mini-frame">{(['TOP','ARMREST','BOTTOM'] as const).map(level=><div className={'mini-level '+(level==='ARMREST'?'mini-armrest':'')} key={level}><span className="mini-level-name">{level==='TOP'?'SUPERIOR':level==='BOTTOM'?'INFERIOR':'ARMREST'}</span><div className="mini-pockets">{Array.from({length:level==='ARMREST'?12:6},(_,i)=>{
  const col=level==='ARMREST'?Math.floor(i/2):i,rowLevel=level==='ARMREST'?(i%2===0?'TOP':'BOTTOM'):level,key=panel(dolly,rowLevel,col),selected=!allowed||!!key&&allowed.includes(key),vehicle=layout.mode==='PAIRED'?col+1:(dolly-1)*3+Math.floor(col/2)+1;
  return <div key={i} className={`mini-pocket dolly-color-${dolly} ${selected?'':'mini-muted'}`} data-panel={key} title={`${level==='ARMREST'?'Armrest de ':''}${key??'Sin asignar'} · vehículo ${vehicle}`}><small>{level==='ARMREST'?'A':`S${vehicle}`}</small><b>{key?.slice(0,2)??'—'}</b><span>{key?.slice(3)??'—'}</span></div>;
 })}</div></div>)}</div><div className="mini-wheels"><i/><i/></div></div>)}</div><div className="preview-key">{allowed?<><span className="preview-selected"/>Color: se escanea en este puesto <span className="preview-unselected"/>Tenue: otro puesto</>:<><span className="preview-selected"/>Cada columna representa una ubicación · ARMREST sigue la ubicación de su panel</>}</div></div>;
}
