import React from 'react';
import {Info} from 'lucide-react';
import type {HmiState} from '../../../shared/types';
import {activeDestination,rackCells} from '../../../shared/stowage';
export function DollyRack({state,dolly}:{state:HmiState;dolly?:number}){
 const destination=activeDestination(state);
 const last=state.sequences.filter(s=>s.status==='COMPLETE').sort((a,b)=>b.id-a.id)[0];
 const selected=dolly??destination?.dolly_number??last?.dolly_number??1;
 const cells=rackCells(state,selected);
 const sequences=state.sequences.filter(s=>s.dolly_number===selected);
 const vehicles=[...new Set(sequences.map(s=>s.sequence_number))];
 const completed=vehicles.filter(n=>sequences.filter(s=>s.sequence_number===n).every(s=>s.status==='COMPLETE')).length;
 const renderRow=(level:'TOP'|'BOTTOM')=><div className="physical-rack-row" key={level}><span className="rack-level">{[...new Set(cells.filter(c=>c.level===level&&c.sequence).map(c=>c.sequence!.position))].join('/')||(level==='TOP'?'FR':'RR')}</span><div className="rack-shelf panel-shelf">{cells.filter(c=>c.level===level).map(c=><div key={c.column} className={'rack-pocket pocket-'+c.paint.toLowerCase()} data-level={level} data-column={c.column} data-paint={c.paint} title={c.sequence?`Secuencia ${c.sequence.sequence_number} · ${c.sequence.hand}`:'Sin pieza asignada'}>{c.paint==='COMPLETE'&&<span className="pocket-check">✓</span>}{c.paint==='ERROR'&&<span className="pocket-check">!</span>}<strong>{c.sequence?String(c.sequence.sequence_number).padStart(4,'0'):'—'}</strong>{c.sequence&&<span className="pocket-type">{c.sequence.position}<br/>{c.sequence.hand}</span>}{c.paint==='CURRENT'&&<small>ACTUAL</small>}</div>)}</div></div>;
 return <div className="physical-dolly"><div className="rack-summary">DOLLY {selected} · {completed}/{state.source.mode==='SQL'?(state.dollyLayout.mode==='PAIRED'?6:3):vehicles.length} VEHÍCULOS</div><div className="rack-legend"><span>● Asignado</span><span>● Actual</span><span>● Error</span></div><div className="rack-structure">{renderRow('TOP')}<div className="physical-rack-row armrest-row"><span className="rack-level">ARMREST</span><div className="rack-shelf armrest-shelf">{Array.from({length:12},(_,i)=>{
 const column=Math.floor(i/2)+1,level=i%2===0?'TOP':'BOTTOM';
 const c=cells.find(cell=>cell.column===column&&cell.level===level)!;
 const current=c.sequence!==null&&state.current!==null&&c.sequence.id===state.current.id;
 const validated=c.sequence?.status==='COMPLETE'||(current&&state.cycle.armrest_plc_ok===1);
 const paint=validated?'complete':current&&c.paint==='ERROR'?'error':current&&['WAITING_ARMREST','VALIDATING_ARMREST'].includes(state.phase)?'current':'empty';
 return <div key={i} className={'rack-pocket pocket-'+paint} title={`${[...new Set(cells.filter(c=>c.level===level&&c.sequence).map(c=>c.sequence!.position))].join('/')||(level==='TOP'?'FR':'RR')} · Columna ${column} · Armrest`} data-armrest-slot={i+1}><strong>{validated?'✓':'—'}</strong>{c.sequence&&<span className="armrest-type">{c.sequence.position}<br/>{c.sequence.hand}</span>}</div>;
 })}</div></div>{renderRow('BOTTOM')}<div className="rack-feet"><i/><i/></div></div><div className="rack-position"><span>POS</span>{[1,2,3,4,5,6].map(n=><span key={n}>{n}</span>)}</div><p className="rack-note"><Info size={16}/>Ubicación automática al terminar la validación de piezas.</p></div>;
}
