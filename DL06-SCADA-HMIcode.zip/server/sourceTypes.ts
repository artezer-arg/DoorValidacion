export interface SourceSelection {date:string;start:number;end:number;}
export interface OrderRow {id:number;clientOrderId:number;sequence:number;date:string;suffix:string;sd:string;reference:string;hand:'LH'|'RH';position:'FR'|'RR';order:number;}
export interface BomRow {id:number;suffix:string;sd:string;}
export interface SourcePanel extends OrderRow {dollyNumber:number;dollyLevel:'TOP'|'BOTTOM';dollyColumn:number;}
export interface SourceVehicle {sequence:number;loadIndex:number;clientOrderId:number;suffix:string;panelSd:string;armrestSd:string;garnishSd:string|null;panels:SourcePanel[];}
export interface SourcePlan {mode:'PREVIEW';selection:SourceSelection;vehicles:SourceVehicle[];totalVehicles:number;totalPanels:number;warnings:string[];importEnabled:false;}
