import {defaultLayout,validateLayout,panelDestination,type DollyLayout} from './dollyLayout.js';
import type {SourceSelection,SourcePlan} from './sourceTypes.js';
import {buildSourcePlan,SourceValidationError} from './sourcePlanner.js';
import {defaultQr,validateQrConfig,validateQr,type QrConfig,type QrKind} from './qrConfig.js';
import type {DatabaseSync} from 'node:sqlite';
import type {Cycle,HmiState,Phase,PlcConfig,Sequence} from './types.js';
import {PlcService,PlcTimeout} from './plcService.js';
import {PrinterService,blockZpl} from './printerService.js';
import {createHash} from 'node:crypto';
import {validateStation,type StationConfig,type PeerSnapshot} from './station.js';
import {seed} from './db.js';
interface Runtime {phase:Phase;resume:Phase;cycle:Cycle;error:string|null;config:PlcConfig;}
export class FsmService {
 private busy=false;private runtime:Runtime; private peerComplete=new Set<number>(); private peerMessage='Sin sincronizar'; private peerFresh=0; private sourceNotice=''; private sourceBlocked=false;
 qrSettings():{profiles:QrConfig;enforceInTest:boolean}{const row=this.db.prepare('SELECT payload FROM qr_config WHERE id=1').get();const settings=row?JSON.parse(String(row.payload)):{profiles:structuredClone(defaultQr),enforceInTest:false};const panel=settings.profiles.PANEL;const fields=['sequence','hand','position','sd'];settings.profiles.PANEL=fields.every(f=>panel.rules.some((r:{field:string})=>r.field===f))?{...panel,rules:panel.rules.filter((r:{field:string})=>fields.includes(r.field))}:structuredClone(defaultQr.PANEL);return settings;}

 configureQr(value:unknown){if(this.busy||this.runtime.cycle.cycle_start_time)throw new Error('Esperar a terminar el panel actual antes de modificar QR');const input=value as {profiles:QrConfig;enforceInTest:boolean};if(typeof input?.enforceInTest!=='boolean')throw new Error('Seleccionar el modo de validación QR');const settings={profiles:validateQrConfig(input.profiles),enforceInTest:input.enforceInTest};this.db.prepare('INSERT INTO qr_config VALUES(1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload').run(JSON.stringify(settings));this.peerFresh=0;this.db.prepare('INSERT INTO qr_config_history(payload,created_at) VALUES(?,?)').run(JSON.stringify(settings),new Date().toISOString());this.event('Formatos QR guardados · '+(settings.enforceInTest?'validación también en modo prueba':'validación en producción'));this.emit();}
 testQr(input:unknown){const v=input as {profiles:QrConfig;kind:QrKind;code:string};if(!['PANEL','ARMREST','GARNISH'].includes(v?.kind))throw new Error('Componente QR inválido');const profiles=validateQrConfig(v.profiles);const expected=this.current(),parsed=validateQr(v.kind,profiles[v.kind],v.code);if(!expected)return parsed;try{return {...validateQr(v.kind,profiles[v.kind],v.code,expected),matches:true};}catch(e){return {...parsed,matches:false,error:e instanceof Error?e.message:String(e)};}}
 sourceWatch():{selection:SourceSelection;curing:number}|null{const r=this.db.prepare('SELECT payload FROM source_watch WHERE id=1').get();if(!r)return null;const w=JSON.parse(String(r.payload));return {selection:{date:w.selection.date,start:w.selection.start,end:w.selection.end},curing:w.curing};}
 private importedSignature(s:Sequence){return JSON.stringify([s.source_order_id,s.source_order,s.sequence_number,s.model,s.hand,s.position,s.reference,s.suffix,s.expected_armrest_sd,s.expected_garnish_code,s.dolly_number,s.dolly_level,s.dolly_column]);}
 private insertSourceRows(plan:SourcePlan,truckId:number,curing:number){
 for(const vehicle of plan.vehicles)for(const panel of vehicle.panels){const garnishRequired=panel.position==='RR'&&vehicle.garnishSd!==null,destination=panelDestination(vehicle.loadIndex,panel.position,panel.hand,this.layout());this.db.prepare('INSERT INTO sequences(truck_id,sequence_number,load_index,model,sd,hand,position,expected_panel_code,expected_armrest_code,expected_armrest_sd,expected_garnish_code,required_curing_minutes,dolly_number,dolly_level,dolly_column,source_order_id,source_order,reference,suffix,garnish_required) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(truckId,vehicle.sequence,vehicle.loadIndex,panel.sd,panel.sd,panel.hand,panel.position,String(panel.id),vehicle.armrestSd,vehicle.armrestSd,vehicle.garnishSd??'NO_APLICA',curing,destination.dollyNumber,destination.dollyLevel,destination.dollyColumn,panel.id,panel.order,panel.reference,panel.suffix,garnishRequired?1:0);}}
 async updateSource(fetchPlan:(s:SourceSelection)=>Promise<SourcePlan>){const watch=this.sourceWatch();if(!watch||this.truck().source_mode!=='SQL'||this.busy)return;const truckId=this.truck().id;try{const plan=await fetchPlan(watch.selection);if(this.busy||this.truck().id!==truckId)return;const existing=this.localSequences(),byId=new Map(plan.vehicles.flatMap(v=>v.panels.map(p=>[p.id,{v,p}] as const)));for(const row of existing){const entry=byId.get(row.source_order_id!);if(!entry)throw new Error('La DB eliminó o dejó incompleta una secuencia ya importada. Revisar programa antes de seguir.');const {v,p}=entry,d=panelDestination(v.loadIndex,p.position,p.hand,this.layout());const signature=JSON.stringify([p.id,p.order,v.sequence,p.sd,p.hand,p.position,p.reference,p.suffix,v.armrestSd,v.garnishSd??'NO_APLICA',d.dollyNumber,d.dollyLevel,d.dollyColumn]);if(signature!==this.importedSignature(row))throw new Error('La DB modificó una orden ya importada. Revisar programa antes de seguir.');}const known=new Set(existing.map(r=>r.source_order_id)),added={...plan,vehicles:plan.vehicles.filter(v=>v.panels.every(p=>!known.has(p.id)))};if(plan.vehicles.some(v=>v.panels.some(p=>known.has(p.id))&&v.panels.some(p=>!known.has(p.id))))throw new Error('Se agregaron paneles a una secuencia ya importada; revisar antes de seguir.');this.db.exec('BEGIN IMMEDIATE');try{this.insertSourceRows(added,truckId,watch.curing);this.db.exec('COMMIT');}catch(e){this.db.exec('ROLLBACK');throw e;}this.sourceBlocked=false;this.sourceNotice=`DB actualizada · ${plan.totalVehicles}/24 secuencias disponibles`+(plan.warnings.find(w=>w.startsWith('Esperando'))?' · '+plan.warnings.find(w=>w.startsWith('Esperando')):'');if(added.vehicles.length)this.event(`DB: incorporadas ${added.vehicles.length} secuencias nuevas, conservando avance`);this.emit();}catch(e){this.sourceBlocked=e instanceof SourceValidationError||(e instanceof Error&&/ya importada/.test(e.message));this.sourceNotice=this.sourceBlocked?(e as Error).message:'No se pudo actualizar SQL. Se conserva el programa disponible; se reintentará automáticamente.';this.emit();}}
 station():StationConfig {const r=this.db.prepare('SELECT payload FROM station_config WHERE id=1').get();return r?JSON.parse(String(r.payload)):{id:'PUESTO-1',allowed:['FR-RH','FR-LH','RR-RH','RR-LH'],peerUrl:'',token:'',printOwner:true};}
 configureStation(input:unknown){if(this.busy||this.runtime.cycle.cycle_start_time||this.sequences().some(s=>s.status==='COMPLETE'))throw new Error('Configurar los puestos antes de iniciar la carga');const next=validateStation(input,this.station());this.db.prepare('INSERT INTO station_config VALUES(1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload').run(JSON.stringify(next));this.peerComplete.clear();this.peerMessage='Sin sincronizar';this.emit();}
 snapshot():PeerSnapshot {const rows=this.localSequences(),watch=this.sourceWatch();return {id:this.station().id,peerUrl:this.station().peerUrl,allowed:this.station().allowed,printOwner:this.station().printOwner,program:createHash('sha256').update(JSON.stringify({mode:this.truck().source_mode,date:this.truck().source_date,selection:watch?.selection??{start:rows[0]?.sequence_number,end:rows.at(-1)?.sequence_number},curing:watch?.curing??rows[0]?.required_curing_minutes,qr:this.qrSettings(),layout:{...this.layout(),showPair:false}})).digest('hex'),manifest:rows.map(r=>({id:r.source_order_id??r.load_index,key:r.position+'-'+r.hand,signature:this.importedSignature(r)})),complete:rows.filter(s=>s.status==='COMPLETE').map(s=>s.source_order_id??s.load_index)};}
 acceptPeer(peer:PeerSnapshot){const local=this.snapshot(),cfg=this.station();if(this.truck().source_mode!=='SQL')throw new Error('Cargar programa SQL en ambos puestos antes de sincronizar');if(!peer||peer.id===local.id||peer.program!==local.program||!Array.isArray(peer.allowed)||!Array.isArray(peer.complete)||!Array.isArray(peer.manifest)||!peer.peerUrl)throw new Error('Los puestos deben tener IDs distintos, enlace recíproco y el mismo programa y distribución');if(peer.printOwner===cfg.printOwner)throw new Error('Elegir un solo puesto para imprimir carteles');if(peer.allowed.some(k=>cfg.allowed.includes(k)))throw new Error('Hay mano/posición asignada a ambos puestos');const manifest=new Map(peer.manifest.map(r=>[r.id,r]));if(manifest.size!==peer.manifest.length)throw new Error('Avance remoto inválido');for(const r of local.manifest){const remote=manifest.get(r.id);if(remote&&remote.signature!==r.signature)throw new Error('Los puestos tienen datos distintos para la misma orden');}if([...local.manifest,...peer.manifest].some(r=>!cfg.allowed.includes(r.key)&&!peer.allowed.includes(r.key)))throw new Error('Hay paneles sin puesto asignado');const permitted=new Set(peer.manifest.filter(r=>peer.allowed.includes(r.key)).map(r=>r.id));if(peer.complete.some(k=>!permitted.has(k)))throw new Error('Avance remoto inválido');this.peerComplete=new Set(peer.complete);this.peerFresh=Date.now();this.peerMessage='Sincronizado con '+peer.id;this.emit();}
 peerFailure(){this.peerFresh=0;this.peerMessage='Sin conexión o configuración incompatible con el otro puesto';this.emit();}
 async refreshPeer(){const cfg=this.station();if(!cfg.peerUrl)return;try{const r=await fetch(cfg.peerUrl+'/api/station/progress',{headers:{'X-DL06-Token':cfg.token},signal:AbortSignal.timeout(3000)});if(!r.ok)throw new Error('No se pudo sincronizar');this.acceptPeer(await r.json() as PeerSnapshot);}catch(e){this.peerFailure();throw e;}}
 readonly testMode=process.env.TEST_MODE!=='false';
 constructor(private db:DatabaseSync,private plc:PlcService,private printer:PrinterService,private broadcast:(state:HmiState)=>void=()=>{}){
 const row=db.prepare('SELECT payload FROM runtime WHERE id=1').get();
 this.runtime=row?JSON.parse(String(row.payload)) as Runtime:{phase:'WAITING_PANEL',resume:'WAITING_PANEL',cycle:{},error:null,config:{mode:'SIMULATOR',behavior:'OK',timeoutMs:5000,latencyMs:350}};
 if(this.runtime.phase.startsWith('VALIDATING_')){this.runtime.phase='ERROR';this.runtime.error='Reinicio durante handshake. Verificar puesto y volver a leer.';}
 if(this.runtime.phase==='SET_COMPLETE') this.runtime.phase=this.truck().completed_sets===24?'TRUCK_COMPLETE':'WAITING_PANEL';
 if(this.truck().source_mode==='SQL'&&!this.sourceWatch()){const first=this.localSequences()[0];if(first&&this.truck().source_date)this.db.prepare('INSERT INTO source_watch VALUES(1,?)').run(JSON.stringify({selection:{date:this.truck().source_date,start:first.sequence_number,end:first.sequence_number+23},curing:first.required_curing_minutes}));}
 const target=this.current();
 if(this.truck().source_mode==='SQL'&&target&&!target.garnish_required&&this.runtime.phase==='WAITING_GARNISH'){
 this.runtime.cycle.garnish_skipped=true;this.runtime.cycle.garnish_plc_ok=0;this.runtime.cycle.garnish_barcode='NO_APLICA';this.runtime.phase='WAITING_DOLLY';this.runtime.resume='WAITING_DOLLY';
 }
 this.save();
 }
 layout():DollyLayout{const row=this.db.prepare("SELECT payload FROM dolly_layout WHERE id=1").get();return row?validateLayout(JSON.parse(String(row.payload))):structuredClone(defaultLayout);}
 configureLayout(value:unknown){
 if(this.busy)throw new Error('Esperar a que termine la operación');
 const next=validateLayout(value),previous=this.layout();
 const mappingChanged=JSON.stringify({...next,showPair:false})!==JSON.stringify({...previous,showPair:false});
 if(mappingChanged&&(this.runtime.cycle.cycle_start_time||this.sequences().some(s=>s.status==='COMPLETE')))throw new Error('La distribución está bloqueada porque comenzó la carga. Puede cambiar la vista de dos dollys.');
 this.db.exec('BEGIN IMMEDIATE');try{
 this.db.prepare('INSERT INTO dolly_layout(id,payload) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload').run(JSON.stringify(next));

 this.db.exec('COMMIT');
 }catch(e){this.db.exec('ROLLBACK');throw e;}
 this.emit();
 }
 private truck(){return this.db.prepare('SELECT * FROM trucks ORDER BY id DESC LIMIT 1').get() as unknown as HmiState['truck'];}
 private localSequences(){return this.db.prepare('SELECT * FROM sequences WHERE truck_id=? ORDER BY load_index, COALESCE(source_order,0), id').all(this.truck().id) as unknown as Sequence[];}
 private sequences(){return this.localSequences().map(s=>s.source_order_id!==null?{...s,expected_panel_code:`${String(s.sequence_number).padStart(4,'0')};${s.hand};${s.position};${s.sd}`}:s).map(s=>this.peerComplete.has(s.source_order_id??s.load_index)?{...s,status:'COMPLETE'}:s);}
 private current(){return this.sequences().find(s=>s.status!=='COMPLETE'&&this.station().allowed.includes(s.position+'-'+s.hand))??null;}
 state():HmiState{const sequences=this.sequences();const groups=new Map<number,Sequence[]>();for(const r of sequences)groups.set(r.load_index,[...(groups.get(r.load_index)??[]),r]);const total=[...groups.values()].filter(g=>g.every(r=>r.status==='COMPLETE')).length;const {token,...station}=this.station();return {qr:this.qrSettings(),availability:{vehicles:groups.size,capacity:24,notice:this.sourceNotice,blocked:this.sourceBlocked},station:{...station,tokenSet:!!token,syncMessage:this.peerMessage,localFinished:!this.current()},dollyLayout:this.layout(),busy:this.busy,source:{mode:this.truck().source_mode,date:this.truck().source_date,station:'DL06'},panelProgress:{completed:sequences.filter(s=>s.status==='COMPLETE').length,total:sequences.length},sequenceRange:{start:this.sourceWatch()?.selection.start??sequences[0]?.sequence_number??1,end:this.sourceWatch()?.selection.end??sequences.at(-1)?.sequence_number??24,editable:this.truck().source_mode==='DEMO'&&!this.busy&&this.truck().completed_sets===0&&this.runtime.phase==='WAITING_PANEL'&&!this.runtime.cycle.cycle_start_time},phase:!this.current()&&!this.busy&&!this.runtime.error?(total===24?'TRUCK_COMPLETE':groups.size<24?'WAITING_SOURCE':'STATION_COMPLETE'):this.runtime.phase,error:this.runtime.error,truck:{...this.truck(),completed_sets:total,status:total===24?'COMPLETE':this.truck().status},current:this.current(),sequences:this.sequences(),cycle:this.runtime.cycle,config:this.runtime.config,testMode:this.testMode,printerMode:this.printer.mode,events:this.db.prepare('SELECT * FROM events ORDER BY id DESC LIMIT 40').all() as unknown as HmiState['events'],eventCount:Number(this.db.prepare('SELECT count(*) AS n FROM events').get()!.n),printJobs:this.db.prepare('SELECT id,block,status,error FROM print_jobs WHERE truck_id=? ORDER BY id').all(this.truck().id) as unknown as HmiState['printJobs']};}
 private save(){this.db.prepare('INSERT INTO runtime VALUES (1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload').run(JSON.stringify(this.runtime));}
 private emit(){this.save();this.broadcast(this.state());}
 private event(message:string){this.db.prepare('INSERT INTO events(time,message) VALUES (?,?)').run(new Date().toISOString(),message);}
 private phase(phase:Phase,message?:string){this.runtime.phase=phase;if(message)this.event(message);this.emit();}
 private fail(error:unknown){this.runtime.error=error instanceof Error?error.message:String(error);this.phase(error instanceof PlcTimeout?'PLC_TIMEOUT':'ERROR',this.runtime.error);}
 async scan(barcode:string,operatorId='J. Pérez'){
 if(this.busy)return;
 if(this.sourceBlocked)throw new Error(this.sourceNotice);
 if(this.station().peerUrl&&Date.now()-this.peerFresh>5000)throw new Error('Sincronizar ambos puestos antes de escanear. Verificar enlace, programa y asignaciones.');
 if(['ERROR','PLC_TIMEOUT'].includes(this.runtime.phase)){if(this.state().printJobs.some(j=>j.status==='FAILED'||j.status==='PENDING')||!['WAITING_PANEL','WAITING_ARMREST','WAITING_GARNISH'].includes(this.runtime.resume))return;this.runtime.phase=this.runtime.resume;this.runtime.error=null;}
 if(!['WAITING_PANEL','WAITING_ARMREST','WAITING_GARNISH','WAITING_DOLLY'].includes(this.runtime.phase))return;
 this.busy=true;this.runtime.resume=this.runtime.phase;
 try{
 if(typeof barcode!=='string'||!barcode.trim()||barcode.length>256)throw new Error('Código inválido (1 a 256 caracteres)');barcode=barcode.trim();
 const s=this.current();if(!s)return;
 if(this.runtime.phase==='WAITING_DOLLY'){
 const expected=`DOLLY-${s.dolly_number}-${s.dolly_level}-${s.dolly_column}`;
 if(!this.testMode&&barcode!==expected)throw new Error(`Destino incorrecto. Esperado ${expected}`);
 if(barcode.includes('FORCE-ERR'))throw new Error('Destino rechazado');
 await this.complete(s);return;
 }
 const step=this.runtime.phase==='WAITING_PANEL'?1:this.runtime.phase==='WAITING_ARMREST'?2:3;
 const kind=step===1?'PANEL':step===2?'ARMREST':'GARNISH';
 const expected=step===1?s.expected_panel_code:step===2?s.expected_armrest_code:s.expected_garnish_code;
 let curing=99;let bondedAt:string|undefined;
 const qr=this.qrSettings();
 if((!this.testMode||qr.enforceInTest)&&(step===2||s.source_order_id!==null||qr.enforceInTest)){const parsed=validateQr(kind,qr.profiles[kind],barcode,s);if(step===2){curing=parsed.curingMinutes!;bondedAt=parsed.bondedAt;}}
 if(!this.testMode&&s.source_order_id===null&&step!==2){
 const c=this.db.prepare('SELECT * FROM components WHERE barcode=?').get(barcode);
 if(barcode!==expected||!c||c.kind!==kind||c.model!==s.model||c.hand!==s.hand||c.position!==s.position)throw new Error('Pieza incompatible: código, modelo, posición o mano');
 if(step===3&&(c.color!=='NEGRO'||c.finish!=='CUERO'))throw new Error('Color o terminación incorrectos');
 }
 if(step===2){if(barcode.includes('-NOCURE'))curing=0;if(curing<s.required_curing_minutes)throw new Error(`Curado insuficiente: ${curing.toFixed(1)} / ${s.required_curing_minutes} min`);}
 if(step===1){this.runtime.cycle.cycle_start_time??=new Date().toISOString();this.runtime.cycle.operator_id=this.station().id+' / '+operatorId;}
 this.phase(`VALIDATING_${kind}` as Phase,`Paso ${step}: validando ${kind} con PLC`);
 const ok=await this.plc.handshake(step,s,this.runtime.config,barcode.includes('FORCE-ERR'));
 if(!ok)throw new Error(`PLC NO OK en paso ${step}`);
 if(step===1){this.runtime.cycle.panel_barcode=barcode;this.runtime.cycle.panel_plc_ok=1;}
 if(step===2){this.runtime.cycle.armrest_barcode=barcode;this.runtime.cycle.armrest_plc_ok=1;this.runtime.cycle.armrest_curing_minutes=curing;this.runtime.cycle.armrest_bonded_at=bondedAt;}
 if(step===3){this.runtime.cycle.garnish_barcode=barcode;this.runtime.cycle.garnish_plc_ok=1;}
 if(step===2&&!s.garnish_required){this.runtime.cycle.garnish_skipped=true;this.runtime.cycle.garnish_plc_ok=0;this.runtime.cycle.garnish_barcode='NO_APLICA';}
 this.phase(step===1?'WAITING_ARMREST':step===2?(s.garnish_required?'WAITING_GARNISH':'WAITING_DOLLY'):'WAITING_DOLLY',`Paso ${step} OK. ${step===3||!s.garnish_required?'Asignando ubicación automáticamente':'Esperando siguiente pieza'}`);
 if(step===3||(step===2&&!s.garnish_required))await this.complete(s);
 }catch(e){this.fail(e);}finally{this.busy=false;this.emit();}
 }
 private async complete(s:Sequence){
 const c=this.runtime.cycle,t=this.truck(),before=t.completed_sets;let count=before;
 if(!c.panel_plc_ok||!c.armrest_plc_ok||(!c.garnish_plc_ok&&!c.garnish_skipped))throw new Error('Ciclo incompleto');
 this.db.exec('BEGIN IMMEDIATE');
 try{
 this.db.prepare('INSERT INTO sets(truck_id,sequence_id,slot_number,panel_barcode,panel_plc_ok,armrest_barcode,armrest_plc_ok,armrest_curing_minutes,garnish_barcode,garnish_plc_ok,garnish_skipped,cycle_start_time,cycle_end_time,operator_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(t.id,s.id,s.dolly_column,c.panel_barcode!,1,c.armrest_barcode!,1,c.armrest_curing_minutes!,c.garnish_barcode!,c.garnish_plc_ok??0,c.garnish_skipped?1:0,c.cycle_start_time!,new Date().toISOString(),c.operator_id!);
 this.db.prepare("UPDATE sequences SET status='COMPLETE' WHERE id=?").run(s.id);
 const groups=new Map<number,Sequence[]>();for(const row of this.sequences()){const list=groups.get(row.load_index)??[];list.push(row);groups.set(row.load_index,list);}
 count=[...groups.values()].filter(rows=>rows.every(r=>r.status==='COMPLETE')).length;
 this.db.prepare('UPDATE trucks SET completed_sets=?,status=? WHERE id=?').run(count,count===24?'COMPLETE':'LOADING',t.id);
 const assigned=this.sequences().filter(r=>r.dolly_number===s.dolly_number),placed=assigned.filter(r=>r.status==='COMPLETE').length;
 this.db.prepare('UPDATE dollys SET status=? WHERE truck_id=? AND dolly_number=?').run(placed===assigned.length&&new Set(assigned.map(r=>r.load_index)).size>=(this.truck().source_mode==='SQL'&&this.layout().mode==='PAIRED'?6:3)?'COMPLETE':placed>0?'LOADING':'PENDING',t.id,s.dolly_number);
 if(!this.station().peerUrl&&count>before&&count%6===0){const block=count/6;const rows=this.sequences().filter(r=>r.load_index>count-6&&r.load_index<=count);this.db.prepare('INSERT INTO print_jobs(truck_id,block,zpl) VALUES (?,?,?)').run(t.id,block,blockZpl(t.truck_code,block,rows));}
 this.runtime.cycle={};this.runtime.phase=count>before&&count%6===0?'BLOCK_PRINTING':count===24?'TRUCK_COMPLETE':'WAITING_PANEL';this.runtime.resume=this.runtime.phase;this.save();this.db.exec('COMMIT');
 }catch(e){this.db.exec('ROLLBACK');throw e;}
 this.phase('SET_COMPLETE',`Secuencia ${String(s.sequence_number).padStart(4,'0')} (${count}/24 vehículos completos) ubicación automática registrada en dolly ${s.dolly_number}`);
 if(!this.station().peerUrl&&count>before&&count%6===0){this.phase('BLOCK_PRINTING','Imprimiendo cartel de bloque');await this.printPending();}
 this.phase(count===24?'TRUCK_COMPLETE':'WAITING_PANEL',count===24?'Camión completo: 24 sets':'Esperando panel siguiente');
 }
 async syncPrintJobs(){if(!this.station().peerUrl||!this.station().printOwner||this.busy)return;const rows=this.sequences();for(let block=1;block<=4;block++){const group=rows.filter(r=>r.load_index>(block-1)*6&&r.load_index<=block*6);if(new Set(group.map(r=>r.load_index)).size===6&&group.every(r=>r.status==='COMPLETE')&&!this.state().printJobs.some(j=>j.block===block))this.db.prepare('INSERT INTO print_jobs(truck_id,block,zpl) VALUES (?,?,?)').run(this.truck().id,block,blockZpl(this.truck().truck_code,block,group));}await this.recover();}
 async printPending(){
 for(const row of this.db.prepare("SELECT * FROM print_jobs WHERE status='PENDING' AND truck_id=?").all(this.truck().id)){
 try{await this.printer.print(Number(row.id),String(row.zpl));this.db.prepare("UPDATE print_jobs SET status=? ,error=NULL WHERE id=?").run(this.printer.mode==='REAL'?'SENT':'SIMULATED',Number(row.id));this.event(`Cartel par ${row.block}: ${this.printer.mode==='REAL'?'enviado a Zebra (sin confirmación física)':'ZPL simulado'}`);}
 catch(e){this.db.prepare("UPDATE print_jobs SET status='FAILED',error=? WHERE id=?").run(String(e),Number(row.id));this.fail(e);throw e;}
 }this.emit();
 }
 async recover(){if(this.busy)return;this.busy=true;try{if(this.runtime.phase==='WAITING_DOLLY'&&this.current())await this.complete(this.current()!);await this.printPending();if(this.runtime.phase==='BLOCK_PRINTING')this.phase(this.truck().completed_sets===24?'TRUCK_COMPLETE':'WAITING_PANEL');}catch(e){this.fail(e);}finally{this.busy=false;this.emit();}}
 dismissError(){if(this.state().printJobs.some(j=>j.status==='FAILED'))return;if(this.busy||!['ERROR','PLC_TIMEOUT'].includes(this.runtime.phase))return;this.runtime.error=null;this.phase(this.runtime.resume,'Error reconocido: reintentar etapa');if(this.runtime.phase==='WAITING_DOLLY')void this.recover();}
 async loadSource(fetchPlan:()=>Promise<SourcePlan>,requiredCuringMinutes:number,replaceActive=false){
 if(this.busy)throw new Error('Puesto ocupado: esperar a que termine la operación');
 if(!replaceActive&&this.truck().source_mode!=='DEMO'&&((this.runtime.phase!=='WAITING_PANEL'&&!(['ERROR','PLC_TIMEOUT'].includes(this.runtime.phase)&&this.runtime.resume==='WAITING_PANEL'))||this.runtime.cycle.cycle_start_time||this.truck().completed_sets!==0||this.sequences().some(s=>s.status==='COMPLETE')))throw new Error('La carga SQL debe hacerse antes de iniciar el primer panel del programa SQL activo');
 if(!Number.isFinite(requiredCuringMinutes)||requiredCuringMinutes<0||requiredCuringMinutes>10080)throw new Error('Mínimo de curado inválido');
 const previousRuntime=structuredClone(this.runtime);this.busy=true;this.emit();
 try{
 const input=await fetchPlan();
 if(replaceActive&&this.station().peerUrl&&input.selection.date===this.sourceWatch()?.selection.date&&input.selection.start===this.sourceWatch()?.selection.start&&input.selection.end===this.sourceWatch()?.selection.end)throw new Error('Elegir una fecha o secuencia inicial distinta para iniciar otro programa sincronizado');
 // Revalidate on server; never trust a submitted client preview.
 const plan=buildSourcePlan(input.selection,input.vehicles.flatMap(v=>v.panels),input.vehicles.flatMap((v,i)=>[{id:i*3,suffix:v.suffix,sd:v.panelSd},{id:i*3+1,suffix:v.suffix,sd:v.armrestSd},...(v.garnishSd?[{id:i*3+2,suffix:v.suffix,sd:v.garnishSd}]:[])]),true);
 this.db.exec('BEGIN IMMEDIATE');
 try{
 this.db.prepare('INSERT INTO runtime_archives(truck_id,payload,created_at,reason) VALUES (?,?,?,?)').run(this.truck().id,JSON.stringify(previousRuntime),new Date().toISOString(),'Activación de programa SQL; estado anterior conservado');
 const inserted=this.db.prepare("INSERT INTO trucks(truck_code,created_at,source_mode,source_date) VALUES (?,?,'SQL',?)").run('SQL-'+plan.selection.date+'-'+Date.now(),new Date().toISOString(),plan.selection.date);
 const truckId=Number(inserted.lastInsertRowid);
 for(let d=1;d<=8;d++)this.db.prepare('INSERT INTO dollys(truck_id,dolly_number,dolly_pair_number) VALUES (?,?,?)').run(truckId,d,Math.ceil(d/2));
 this.db.prepare('INSERT INTO source_watch VALUES(1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload').run(JSON.stringify({selection:plan.selection,curing:requiredCuringMinutes}));
 this.insertSourceRows(plan,truckId,requiredCuringMinutes);
 this.sourceBlocked=false;this.sourceNotice=`DB: ${plan.totalVehicles}/24 secuencias disponibles · actualización automática`;
 this.peerComplete.clear();this.peerFresh=0;this.peerMessage='Sin sincronizar';this.runtime.cycle={};this.runtime.error=null;this.runtime.phase='WAITING_PANEL';this.runtime.resume='WAITING_PANEL';this.save();this.event(`Programa SQL DL06 cargado: ${plan.selection.start}–${plan.selection.end}, ${plan.totalVehicles}/24 vehículos disponibles, ${plan.totalPanels} paneles`);
 this.db.exec('COMMIT');
 }catch(e){this.db.exec('ROLLBACK');this.runtime=previousRuntime;throw e;}
 }finally{this.busy=false;this.emit();}
 }
 setSequenceRange(start:number,end:number){
 if(!Number.isInteger(start)||!Number.isInteger(end)||start<0||end>9999||end-start!==23)throw new Error('El rango debe contener exactamente 24 secuencias consecutivas (0000–9999)');
 if(!this.state().sequenceRange.editable)throw new Error('El rango solo puede cambiarse antes de iniciar la carga del camión');
 const rows=this.sequences();
 this.db.exec('BEGIN IMMEDIATE');
 try{
 // Move into a temporary valid range disjoint from current and target to avoid UNIQUE collisions.
 const used=new Set([...rows.map(r=>r.sequence_number),...Array.from({length:24},(_,i)=>start+i)]);
 const temp:number[]=[];for(let n=0;temp.length<24;n++)if(!used.has(n))temp.push(n);
 const update=this.db.prepare('UPDATE sequences SET sequence_number=? WHERE id=?');
 rows.forEach((r,i)=>update.run(temp[i],r.id));
 rows.forEach(r=>update.run(start+r.load_index-1,r.id));
 this.event(`Rango del camión configurado: ${String(start).padStart(4,'0')} a ${String(end).padStart(4,'0')} (24 secuencias)`);
 this.db.exec('COMMIT');
 }catch(e){this.db.exec('ROLLBACK');throw e;}
 this.emit();
 }
 configure(config:Partial<PlcConfig>){if(this.busy)throw new Error('Puesto ocupado');
 if(typeof config!=='object'||config===null)throw new Error('Configuración inválida');if(config.mode&&!['SIMULATOR','REAL'].includes(config.mode))throw new Error('Modo PLC inválido');if(config.behavior&&!['OK','FAIL','TIMEOUT'].includes(config.behavior))throw new Error('Comportamiento inválido');
 for(const k of ['timeoutMs','latencyMs'] as const)if(config[k]!==undefined&&(!Number.isFinite(config[k])||config[k]!<1||config[k]!>30000))throw new Error(`${k} inválido`);
 this.runtime.config={...this.runtime.config,...config};this.event('Configuración PLC actualizada');this.emit();}
 async retryPrint(){if(this.busy)return;this.db.prepare("UPDATE print_jobs SET status='PENDING' WHERE status='FAILED'").run();await this.recover();if(this.runtime.phase==='ERROR'&&!this.state().printJobs.some(j=>j.status==='FAILED')){this.runtime.error=null;this.phase(this.truck().completed_sets===24?'TRUCK_COMPLETE':'WAITING_PANEL');}}
 reset(){if(this.truck().source_mode==='SQL')throw new Error('No se puede borrar un programa SQL desde Reiniciar demo');if(this.busy)throw new Error('No se puede reiniciar durante una operación');if(!this.testMode)throw new Error('Reset disponible solo en prueba');this.db.exec('BEGIN IMMEDIATE; DELETE FROM source_watch;DELETE FROM runtime;DELETE FROM print_jobs;DELETE FROM sets;DELETE FROM sequences;DELETE FROM dollys;DELETE FROM trucks;DELETE FROM components;DELETE FROM events;COMMIT;');seed(this.db);this.runtime={phase:'WAITING_PANEL',resume:'WAITING_PANEL',cycle:{},error:null,config:this.runtime.config};this.event('Demo reiniciada');this.emit();}
}
