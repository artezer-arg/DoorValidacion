import {DatabaseConfigStore,DatabaseConfigError,type DatabaseConfig} from './databaseConfig.js';
import sql from 'mssql';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import type {BomRow,OrderRow,SourceSelection,SourcePlan} from './sourceTypes.js';
import {buildSourcePlan,validateSelection} from './sourcePlanner.js';
/** Read-only SQL source; stored secrets are never returned to the browser. */
export class SqlServerSource {
 private activeReads=0;private changing=false;
 private poolPromise:Promise<sql.ConnectionPool>|null=null;
 constructor(readonly settings=new DatabaseConfigStore()){}
 configured(){return this.settings.configured();}
 private config(c:DatabaseConfig):sql.config{return {server:c.server,database:c.database,user:c.user,password:c.password,...(c.instance?{}:{port:c.port}),connectionTimeout:5000,requestTimeout:15000,pool:{max:2,min:0,idleTimeoutMillis:30000},options:{...(c.instance?{instanceName:c.instance}:{}),encrypt:c.encrypt,trustServerCertificate:c.trustServerCertificate,useUTC:true,enableArithAbort:true}};}
 async saveSettings(input:unknown){const candidate=this.settings.candidate(input);if(this.changing||this.activeReads)throw new DatabaseConfigError('Hay una lectura o cambio de DB en curso; volver a intentar');this.changing=true;try{await this.close();return this.settings.save(candidate);}finally{this.changing=false;}}
 async testSettings(input:unknown){const candidate=this.settings.candidate(input),pool=new sql.ConnectionPool(this.config(candidate));try{await pool.connect();await pool.request().query('SELECT TOP (0) ID_OrdenProduccion, ID_OrdenCliente, Secuencia, Fecha_Secuencia, Suffix, SD, Referencia, Mano, Posicion, Orden FROM dbo.Orden_Produccion; SELECT TOP (0) ID_BOM, Suffix, SD FROM dbo.BOM_Suffix;');return {ok:true,message:"Conexión OK y lectura permitida en Orden_Produccion y BOM_Suffix"};}finally{await pool.close().catch(()=>{});}}
 private async pool(){
 if(!this.configured())throw new Error('Configurar la conexión en Configuración de base de datos');
 if(!this.poolPromise){const pool=new sql.ConnectionPool(this.config(this.settings.get()));pool.on('error',error=>console.error('SQL Server connection error:',error.code));this.poolPromise=pool.connect().catch(error=>{this.poolPromise=null;throw error;});}
 return this.poolPromise;
 }
 async programs(){
 if(this.changing)throw new DatabaseConfigError('Cambio de DB en curso');this.activeReads++;
 try{const pool=await this.pool();const result=await pool.request().query(readFileSync(resolve('sql/programas_disponibles_dl06.sql'),'utf8'));return result.recordset as {date:string;panels:number;vehicles:number;firstSequence:number;lastSequence:number}[];}finally{this.activeReads--;}
 }
 async preview(selection:SourceSelection):Promise<SourcePlan>{if(this.changing)throw new DatabaseConfigError('Cambio de DB en curso');this.activeReads++;try{return await this.readPreview(selection);}finally{this.activeReads--;}}
 private async readPreview(selection:SourceSelection):Promise<SourcePlan>{
 validateSelection(selection);const pool=await this.pool(),transaction=new sql.Transaction(pool);let active=false;
 try{
 // REPEATABLE_READ keeps selected rows stable between program and BOM reads; no dirty reads.
 await transaction.begin(sql.ISOLATION_LEVEL.REPEATABLE_READ);active=true;
 const result=await transaction.request().input('fecha',sql.Date,new Date(selection.date+'T00:00:00Z')).input('desde',sql.Int,selection.start).input('hasta',sql.Int,selection.end).query(readFileSync(resolve('sql/leer_programa_dl01.sql'),'utf8'));
 const recordsets=result.recordsets as sql.IRecordSet<unknown>[];
 const plan=buildSourcePlan(selection,recordsets[0] as OrderRow[],recordsets[1] as BomRow[],true);
 await transaction.commit();active=false;return plan;
 }catch(error){if(active)await transaction.rollback().catch(()=>{});throw error;}
 }
 async close(){if(this.poolPromise){const pool=await this.poolPromise.catch(()=>null);this.poolPromise=null;await pool?.close();}}
}
