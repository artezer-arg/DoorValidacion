import {formatArmrestBarcode} from './armrestBarcode.js';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
export function openDb(path=process.env.DB_PATH??'dl06_production.db') {
 const db=new DatabaseSync(path);db.exec('CREATE TABLE IF NOT EXISTS qr_config_history(id INTEGER PRIMARY KEY,payload TEXT NOT NULL,created_at TEXT NOT NULL)');db.exec('CREATE TABLE IF NOT EXISTS qr_config(id INTEGER PRIMARY KEY CHECK(id=1),payload TEXT NOT NULL)');db.exec('CREATE TABLE IF NOT EXISTS source_watch(id INTEGER PRIMARY KEY CHECK(id=1),payload TEXT NOT NULL)');db.exec('CREATE TABLE IF NOT EXISTS station_config(id INTEGER PRIMARY KEY CHECK(id=1),payload TEXT NOT NULL)');db.exec(readFileSync(resolve('schema.sql'),'utf8'));migrateSequences(db);
 if(!db.prepare('PRAGMA table_info(sequences)').all().some(c=>c.name==='expected_armrest_sd'))db.exec('ALTER TABLE sequences ADD COLUMN expected_armrest_sd TEXT');
 // Known demo profiles only; actual programs must use BOM_Suffix.
 db.exec("UPDATE sequences SET expected_armrest_sd=CASE model WHEN 'P3A' THEN 'A3L' WHEN 'P1A' THEN 'A1H' WHEN 'P3C' THEN 'A3H' WHEN 'D4L' THEN 'A4L' END WHERE expected_armrest_sd IS NULL");db.exec('PRAGMA busy_timeout=5000; PRAGMA synchronous=FULL;');
 if(!db.prepare('SELECT id FROM trucks LIMIT 1').get()) seed(db);
 // Apply corrected RR garnish association only to unfinished SQL targets.
 db.exec("UPDATE sequences SET garnish_required=CASE WHEN position='RR' AND expected_garnish_code<>'NO_APLICA' THEN 1 ELSE 0 END WHERE status<>'COMPLETE' AND truck_id IN (SELECT id FROM trucks WHERE source_mode='SQL')");
 return db;
}
export function seed(db:DatabaseSync){
 db.exec('BEGIN IMMEDIATE');
 try {
 db.prepare('INSERT INTO trucks(truck_code,created_at) VALUES (?,?)').run('7714',new Date().toISOString());
 const id=Number((db.prepare('SELECT id FROM trucks ORDER BY id DESC LIMIT 1').get()!).id);
 for(let d=1;d<=8;d++) db.prepare('INSERT INTO dollys(truck_id,dolly_number,dolly_pair_number) VALUES (?,?,?)').run(id,d,Math.ceil(d/2));
 for(let n=1;n<=24;n++){
 const model=['P3A','P1A','P3C','D4L'][Math.floor((n-1)/6)],hand=n%2?'RH':'LH',position=(n%3===0&&model!=='P1A')?'RR':'FR',dolly=Math.floor((n-1)/3)+1,col=(n-1)%3+1;
 const armrestSd=['A3L','A1H','A3H','A4L'][Math.floor((n-1)/6)],armrestCode=formatArmrestBarcode(armrestSd,position,hand,Date.now()-99*60000-n*1000);
 db.prepare('INSERT INTO sequences(truck_id,sequence_number,load_index,model,sd,hand,position,expected_panel_code,expected_armrest_code,expected_armrest_sd,expected_garnish_code,required_curing_minutes,dolly_number,dolly_level,dolly_column) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,n,n,model,'SEQ-'+String(841+n),hand,position,`PNL-${model}-${position}-${hand}-${n}`,armrestCode,armrestSd,`GAR-${model}-${hand}-NEGRO-CUERO-${n}`,60,dolly,position==='FR'?'TOP':'BOTTOM',col);
 for(const [kind,code] of [['PANEL',`PNL-${model}-${position}-${hand}-${n}`],['ARMREST',armrestCode],['GARNISH',`GAR-${model}-${hand}-NEGRO-CUERO-${n}`]]) db.prepare('INSERT INTO components VALUES (?,?,?,?,?,?,?,?)').run(code,kind,model,hand,position,'NEGRO','CUERO',new Date(Date.now()-99*60000).toISOString());
 } db.exec('COMMIT');
 }catch(e){db.exec('ROLLBACK');throw e;}
}

/** Migrate without changing IDs referenced by existing traceability records. */
function migrateSequences(db:DatabaseSync){
 const source=readFileSync(resolve('schema.sql'),'utf8');
 const statement=(table:string)=>source.split(';').find(s=>s.includes(`CREATE TABLE IF NOT EXISTS ${table}(`))!;
 const sequenceSql=String(db.prepare("SELECT sql FROM sqlite_master WHERE name='sequences'").get()!.sql);
 const setsSql=String(db.prepare("SELECT sql FROM sqlite_master WHERE name='sets'").get()!.sql);
 const rebuildSequences=!sequenceSql.includes('source_order_id');
 const rebuildSets=!setsSql.includes('garnish_skipped');
 db.exec('PRAGMA foreign_keys=OFF; BEGIN IMMEDIATE');
 try{
 for(const [table,rebuild] of [['sequences',rebuildSequences],['sets',rebuildSets]] as const){
 if(!rebuild)continue;
 const columns=db.prepare(`PRAGMA table_info(${table})`).all().map(c=>String(c.name));
 db.exec(statement(table).replace(`CREATE TABLE IF NOT EXISTS ${table}(`,`CREATE TABLE ${table}_new(`));
 const target=columns.slice(),selection=columns.slice();
 if(table==='sequences'&&!columns.includes('load_index')){target.push('load_index');selection.push('sequence_number');}
 db.exec(`INSERT INTO ${table}_new(${target.join(',')}) SELECT ${selection.join(',')} FROM ${table}`);
 db.exec(`DROP TABLE ${table}; ALTER TABLE ${table}_new RENAME TO ${table};`);
 }
 const truckCols=db.prepare('PRAGMA table_info(trucks)').all().map(c=>c.name);
 if(!truckCols.includes('source_mode'))db.exec("ALTER TABLE trucks ADD COLUMN source_mode TEXT NOT NULL DEFAULT 'DEMO'");
 if(!truckCols.includes('source_date'))db.exec('ALTER TABLE trucks ADD COLUMN source_date TEXT');
 if(db.prepare('PRAGMA foreign_key_check').all().length)throw new Error('Migración inválida: referencias de trazabilidad');
 db.exec('COMMIT');
 }catch(e){db.exec('ROLLBACK');throw e;}finally{db.exec('PRAGMA foreign_keys=ON');}
}
