export type QrKind='PANEL'|'ARMREST'|'GARNISH';
export type QrField='orderId'|'reference'|'sd'|'position'|'hand'|'sequence'|'suffix'|'bondedAt';
export interface QrRule {field:QrField;start:number;length:number;}
export interface QrProfile {format:'FIXED'|'DELIMITED';delimiter:string;prefix:string;suffix:string;totalLength:number;uppercase:boolean;rules:QrRule[];}
export type QrConfig=Record<QrKind,QrProfile>;
export const qrLabels:Record<QrField,string>={orderId:'ID de orden',reference:'Referencia',sd:'SD',position:'Posición FR/RR',hand:'Mano LH/RH',sequence:'Secuencia',suffix:'Suffix',bondedAt:'Fecha y hora de encolado'};
export const qrFields:Record<QrKind,QrField[]>={PANEL:['sequence','hand','position','sd'],ARMREST:['bondedAt','sd','position','hand','sequence'],GARNISH:['sd','position','hand']};
const base:QrProfile={format:'FIXED',delimiter:';',prefix:'',suffix:'',totalLength:0,uppercase:true,rules:[]};
export const defaultQr:QrConfig={PANEL:{...base,format:'DELIMITED',rules:[{field:'sequence',start:1,length:0},{field:'hand',start:2,length:0},{field:'position',start:3,length:0},{field:'sd',start:4,length:0}]},ARMREST:{...base,totalLength:21,rules:[{field:'bondedAt',start:1,length:14},{field:'sd',start:15,length:3},{field:'position',start:18,length:2},{field:'hand',start:20,length:2}]},GARNISH:{...base,rules:[{field:'sd',start:1,length:0}]}};
