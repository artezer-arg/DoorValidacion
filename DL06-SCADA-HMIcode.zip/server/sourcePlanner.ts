import type {BomRow,OrderRow,SourceSelection,SourcePlan,SourceVehicle} from './sourceTypes.js';
export class SourceValidationError extends Error {}
const normalized=(value:unknown)=>typeof value==='string'?value.trim().toUpperCase():'';
export function validateSelection(selection:SourceSelection){
 if(!selection||typeof selection.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(selection.date))throw new SourceValidationError('Elegir fecha del programa');
 const date=new Date(selection.date+'T00:00:00Z');
 if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==selection.date)throw new SourceValidationError('Fecha del programa inválida');
 if(!Number.isInteger(selection.start)||!Number.isInteger(selection.end)||selection.start<0||selection.end>9999||selection.end-selection.start!==23)throw new SourceValidationError('Seleccionar exactamente 24 secuencias consecutivas');
}
/** DL06 uses D panels, A + numeric model armrests, and G garnish. Other BOM components are outside this validation. */
export function buildSourcePlan(selection:SourceSelection,orders:OrderRow[],bom:BomRow[],incremental=false):SourcePlan{
 validateSelection(selection);selection={date:selection.date,start:selection.start,end:selection.end};const warnings:string[]=[],vehicles:SourceVehicle[]=[];
 const ids=new Set<number>();
 for(const row of orders){
 if(!Number.isSafeInteger(row.id)||row.id<1||ids.has(row.id))throw new SourceValidationError('ID_OrdenProduccion repetido o inválido');ids.add(row.id);
 const date=new Date(row.date+'T00:00:00Z');if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==row.date)throw new SourceValidationError('Fecha de registro inválida');
 if((row.sequence===selection.start&&row.date!==selection.date)||row.sequence<selection.start||row.sequence>selection.end||!Number.isInteger(row.sequence))throw new SourceValidationError('Primera secuencia fuera de fecha o registros fuera de rango');
 }
 for(let index=1;index<=24;index++){
 const sequence=selection.start+index-1;
 const panels=orders.filter(r=>r.sequence===sequence).map(r=>({...r,suffix:normalized(r.suffix),sd:normalized(r.sd),reference:normalized(r.reference),hand:normalized(r.hand) as OrderRow['hand'],position:normalized(r.position) as OrderRow['position']})).sort((a,b)=>a.order-b.order||a.id-b.id);
 if(incremental&&(panels.length<2||panels.length===3)){warnings.push(`Esperando secuencia ${sequence}: ${panels.length} paneles disponibles. Las siguientes quedan en espera para mantener el orden.`);break;}
 if(panels.length!==2&&panels.length!==4)throw new SourceValidationError(`Secuencia ${sequence}: se esperan 2 o 4 paneles DL06; encontrados ${panels.length}`);
 if(new Set(panels.map(p=>p.date)).size!==1)throw new SourceValidationError(`Secuencia ${sequence}: registros de varios programas/fechas; revisar la orden cliente`);
 const suffix=panels[0].suffix,clientOrderId=panels[0].clientOrderId,sd=panels[0].sd;
 if(!suffix||!sd||!Number.isSafeInteger(clientOrderId)||clientOrderId<1||panels.some(r=>r.suffix!==suffix||r.clientOrderId!==clientOrderId||r.sd!==sd))throw new SourceValidationError(`Secuencia ${sequence}: programa ambiguo (Suffix, SD u orden cliente)`);
 const locations=new Set<string>();
 for(const row of panels){
 if(!['LH','RH'].includes(row.hand)||!['FR','RR'].includes(row.position)||!row.reference||!Number.isInteger(row.order))throw new SourceValidationError(`Secuencia ${sequence}: mano, posición, referencia u orden inválidos`);
 const key=row.position+'-'+row.hand;if(locations.has(key))throw new SourceValidationError(`Secuencia ${sequence}: panel duplicado ${key}`);locations.add(key);
 }
 if(!locations.has('FR-LH')||!locations.has('FR-RH')||(panels.length===4&&(!locations.has('RR-LH')||!locations.has('RR-RH'))))throw new SourceValidationError(`Secuencia ${sequence}: juego de paneles incompleto`);
 const sdSet=[...new Set(bom.filter(r=>normalized(r.suffix)===suffix).map(r=>normalized(r.sd)))];
 if(!sdSet.length)throw new SourceValidationError(`Sin BOM_Suffix para ${suffix}`);
 if(sdSet.some(s=>!s))throw new SourceValidationError(`Suffix ${suffix}: SD vacío en BOM`);
 const d=sdSet.filter(s=>s.startsWith('D')),a=sdSet.filter(s=>/^A[0-9][A-Z0-9]*$/.test(s)),g=sdSet.filter(s=>s.startsWith('G'));
 const other=sdSet.filter(s=>!d.includes(s)&&!a.includes(s)&&!g.includes(s));
 if(other.length){const notice=`Suffix ${suffix}: componentes fuera de PANEL/ARMREST/GARNISH: ${other.join(', ')}. No se usan en esta validación.`;if(!warnings.includes(notice))warnings.push(notice);}
 if(d.length!==1||d[0]!==sd||a.length!==1||g.length>1)throw new SourceValidationError(`Suffix ${suffix}: BOM ambiguo o panel SD incompatible`);
 if(!g.length&&!warnings.includes(`Suffix ${suffix}: no hay Garnish en BOM; confirmar si no aplica.`))warnings.push(`Suffix ${suffix}: no hay Garnish en BOM; confirmar si no aplica.`);
 vehicles.push({sequence,loadIndex:index,clientOrderId,suffix,panelSd:d[0],armrestSd:a[0],garnishSd:g[0]??null,panels:panels.map(r=>({...r,dollyNumber:Math.floor((index-1)/3)+1,dollyLevel:r.position==='FR'?'TOP':'BOTTOM',dollyColumn:((index-1)%3)*2+(r.hand==='LH'?1:2)}))});
 }
 return {mode:'PREVIEW',selection,vehicles,totalVehicles:vehicles.length,totalPanels:vehicles.reduce((n,v)=>n+v.panels.length,0),warnings,importEnabled:false};
}
