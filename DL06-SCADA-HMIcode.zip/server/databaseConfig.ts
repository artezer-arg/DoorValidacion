import {createCipheriv,createDecipheriv,randomBytes} from 'node:crypto';
import {existsSync,readFileSync,writeFileSync,renameSync,chmodSync,mkdirSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
export interface DatabaseConfig {server:string;database:string;user:string;password:string;port:number;instance:string;encrypt:boolean;trustServerCertificate:boolean;}
export type PublicDatabaseConfig=Omit<DatabaseConfig,'password'>&{passwordSet:boolean};
export class DatabaseConfigError extends Error {}
export class DatabaseConfigStore {
 private value:DatabaseConfig;
 private configPath:string;private keyPath:string;
 constructor(directory=process.env.DL06_CONFIG_DIR??'config'){
 this.configPath=resolve(directory,'database.json');this.keyPath=resolve(directory,'database.key');
 const fallback:DatabaseConfig={server:process.env.MSSQL_SERVER??'',database:process.env.MSSQL_DATABASE??'TB-L',user:process.env.MSSQL_USER??'',password:process.env.MSSQL_PASSWORD??'',port:Number(process.env.MSSQL_PORT??1433),instance:'',encrypt:process.env.MSSQL_ENCRYPT!=='false',trustServerCertificate:process.env.MSSQL_TRUST_CERTIFICATE==='true'};
 if(existsSync(this.configPath)){
 try{const saved=JSON.parse(readFileSync(this.configPath,'utf8'));const {passwordEncrypted,...fields}=saved;const parts=String(passwordEncrypted).split('.');const decipher=createDecipheriv('aes-256-gcm',readFileSync(this.keyPath),Buffer.from(parts[0],'base64'));decipher.setAuthTag(Buffer.from(parts[1],'base64'));const password=Buffer.concat([decipher.update(Buffer.from(parts[2],'base64')),decipher.final()]).toString('utf8');this.value=this.validate({...fields,password},fallback);}catch{throw new DatabaseConfigError('No se pudo leer la configuración de DB. Conservar database.json y database.key juntos.');}
 }else this.value=fallback;
 }
 private validate(input:unknown,current=this.value):DatabaseConfig{
 if(!input||typeof input!=='object'||Array.isArray(input))throw new DatabaseConfigError('Configuración inválida');
 const p=input as Record<string,unknown>;
 const field=(key:string,max:number)=>{if(typeof p[key]!=='string'||(p[key] as string).length>max||/[\x00-\x1f]/.test(p[key] as string))throw new DatabaseConfigError(`Campo ${key} inválido`);return (p[key] as string).trim();};
 let server=field('server',255),instance=field('instance',128);const database=field('database',128),user=field('user',128),port=p.port;
 if(server.includes('\\')){const parts=server.split('\\');if(parts.length!==2||!parts[0]||!parts[1]||(instance&&instance!==parts[1]))throw new DatabaseConfigError('Servidor/instancia inválido');[server,instance]=parts;}
 if(!server||!database||!user)throw new DatabaseConfigError('Completar servidor, base de datos y usuario');
 if(typeof port!=='number'||!Number.isInteger(port)||port<1||port>65535)throw new DatabaseConfigError('Puerto debe estar entre 1 y 65535');
 if(typeof p.encrypt!=='boolean'||typeof p.trustServerCertificate!=='boolean')throw new DatabaseConfigError('Opciones de seguridad inválidas');
 let password:string;
 if(p.password===undefined||p.password==='')password=current.password;
 else {if(typeof p.password!=='string'||p.password.length>1024||p.password.includes('\0'))throw new DatabaseConfigError('Contraseña inválida');password=p.password;}
 if(!password)throw new DatabaseConfigError('Ingresar contraseña de SQL Server');
 return {server,instance,database,user,password,port,encrypt:p.encrypt,trustServerCertificate:p.trustServerCertificate};
 }
 candidate(input:unknown){return this.validate(input);}
 get(){return {...this.value};}
 public():PublicDatabaseConfig{const {password,...fields}=this.value;return {...fields,passwordSet:!!password};}
 configured(){return !!(this.value.server&&this.value.database&&this.value.user&&this.value.password);}
 save(input:unknown){const value=this.candidate(input);mkdirSync(dirname(this.configPath),{recursive:true,mode:0o700});
 if(!existsSync(this.keyPath))writeFileSync(this.keyPath,randomBytes(32),{mode:0o600,flag:'wx'});
 const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',readFileSync(this.keyPath),iv);const encrypted=Buffer.concat([cipher.update(value.password,'utf8'),cipher.final()]);const {password,...fields}=value;
 const payload=JSON.stringify({...fields,passwordEncrypted:[iv,cipher.getAuthTag(),encrypted].map(b=>b.toString('base64')).join('.')},null,2);
 const temp=this.configPath+'.'+randomBytes(8).toString('hex')+'.tmp';writeFileSync(temp,payload,{mode:0o600,flag:'wx'});renameSync(temp,this.configPath);chmodSync(this.configPath,0o600);this.value=value;return this.public();}
}
