import {defaultQr,qrFields,type QrConfig,type QrKind,type QrProfile,type QrField} from './qrTypes.js';
import {parseBondedAt} from './armrestBarcode.js';
export {defaultQr};export type {QrConfig,QrKind};
export function validateQrConfig(value:unknown):QrConfig{
 const result={} as QrConfig;
 for(const kind of ['PANEL','ARMREST','GARNISH'] as QrKind[]){const p=(value as QrConfig)?.[kind];if(!p||!['FIXED','DELIMITED'].includes(p.format)||typeof p.uppercase!=='boolean'||typeof p.prefix!=='string'||typeof p.suffix!=='string'||p.prefix.length>64||p.suffix.length>64||typeof p.delimiter!=='string'||!p.delimiter.length||p.delimiter.length>4||/[\r\n]/.test(p.delimiter)||!Number.isInteger(p.totalLength)||p.totalLength<0||p.totalLength>256||!Array.isArray(p.rules)||!p.rules.length||p.rules.length>8)throw new Error(`Formato QR ${kind} inválido`);
 const seen=new Set<string>();for(const r of p.rules){if(!r||!qrFields[kind].includes(r.field)||seen.has(r.field)||!Number.isInteger(r.start)||r.start<1||r.start>256||!Number.isInteger(r.length)||r.length<0||r.length>256)throw new Error(`Campos QR ${kind} inválidos`);seen.add(r.field);}
 if(p.format==='FIXED'){for(let i=0;i<p.rules.length;i++){const a=p.rules[i],end=a.length?a.start+a.length-1:Infinity;if(p.totalLength&&a.length&&end>p.totalLength-p.prefix.length-p.suffix.length)throw new Error(`Campo ${a.field} fuera del largo QR`);for(let j=i+1;j<p.rules.length;j++){const b=p.rules[j],bEnd=b.length?b.start+b.length-1:Infinity;if(a.start<=bEnd&&b.start<=end)throw new Error(`Campos superpuestos en ${kind}`);}}}
 else if(new Set(p.rules.map(r=>r.start)).size!==p.rules.length)throw new Error(`Columnas repetidas en ${kind}`);
 if(kind==='PANEL'&&!['sequence','hand','position','sd'].every(f=>seen.has(f)))throw new Error('Panel requiere secuencia, mano, posición y SD');
 if(kind==='ARMREST'&&!['bondedAt','sd','position','hand'].every(f=>seen.has(f)))throw new Error('Armrest requiere fecha/hora, SD, posición y mano');
 if(kind==='GARNISH'&&!seen.has('sd'))throw new Error('Garnish requiere SD');
 result[kind]=structuredClone(p);
 }return result;
}
export function parseQr(profile:QrProfile,code:string):Partial<Record<QrField,string>>{
 if(typeof code!=='string'||!code.trim()||code.trim().length>256)throw new Error('Código QR vacío o demasiado largo');
 const original=code.trim();if(profile.totalLength&&original.length!==profile.totalLength)throw new Error(`Largo QR incorrecto: ${original.length}, esperado ${profile.totalLength}`);
 if(!original.startsWith(profile.prefix)||!original.endsWith(profile.suffix)||original.length<profile.prefix.length+profile.suffix.length)throw new Error('Prefijo o terminación QR incorrectos');
 const payload=original.slice(profile.prefix.length,profile.suffix.length?-profile.suffix.length:undefined),columns=profile.format==='DELIMITED'?payload.split(profile.delimiter):[];const result:Partial<Record<QrField,string>>={};
 for(const rule of profile.rules){let part:string;if(profile.format==='FIXED'){if(rule.start>payload.length||(rule.length&&rule.start+rule.length-1>payload.length))throw new Error(`QR incompleto en ${rule.field}`);part=payload.slice(rule.start-1,rule.length?rule.start-1+rule.length:undefined);}else{if(columns[rule.start-1]===undefined)throw new Error(`Falta columna de ${rule.field}`);part=columns[rule.start-1];}part=part.trim();if(!part)throw new Error(`Campo ${rule.field} vacío`);result[rule.field]=profile.uppercase?part.toUpperCase():part;}
 return result;
}
export interface QrExpected {source_order_id:number|null;reference:string|null;sd:string;position:string;hand:string;sequence_number:number;suffix:string|null;expected_armrest_sd:string|null;expected_garnish_code:string;required_curing_minutes:number;}
export function validateQr(kind:QrKind,profile:QrProfile,code:string,expected?:QrExpected,now=Date.now()){
 const fields=parseQr(profile,code);let armrest:ReturnType<typeof parseBondedAt>|undefined;
 if(kind==='ARMREST')armrest=parseBondedAt(fields.bondedAt!,now);
 for(const key of ['orderId','sequence'] as const)if(fields[key]!==undefined&&(!/^\d+$/.test(fields[key]!)||!Number.isSafeInteger(Number(fields[key]))))throw new Error(`${key==='orderId'?'ID de orden':'Secuencia'} debe ser numérico`);
 if(fields.position!==undefined&&!['FR','RR'].includes(fields.position))throw new Error('Posición QR inválida: FR/RR');if(fields.hand!==undefined&&!['LH','RH'].includes(fields.hand))throw new Error('Mano QR inválida: LH/RH');
 if(expected){const targets:Partial<Record<QrField,string|null>>={orderId:expected.source_order_id===null?null:String(expected.source_order_id),reference:expected.reference,sd:kind==='PANEL'?expected.sd:kind==='ARMREST'?expected.expected_armrest_sd:expected.expected_garnish_code,position:expected.position,hand:expected.hand,sequence:String(expected.sequence_number),suffix:expected.suffix};for(const [field,value] of Object.entries(fields)){if(field==='bondedAt')continue;const target=targets[field as QrField];if(target==null||((field==='orderId'||field==='sequence')?Number(value)!==Number(target):value!==(profile.uppercase?target.toUpperCase():target)))throw new Error(`QR ${kind} incorrecto · ${field}: ${value}, esperado ${target??'sin configurar'}`);}if(armrest&&armrest.curingMinutes<expected.required_curing_minutes)throw new Error(`Curado insuficiente: ${armrest.curingMinutes.toFixed(1)} / ${expected.required_curing_minutes} min`);}
 return {fields,bondedAt:armrest?.bondedAt,curingMinutes:armrest?.curingMinutes,comparison:expected?'Coincide con objetivo actual':'Formato válido; sin objetivo para comparar'};
}
