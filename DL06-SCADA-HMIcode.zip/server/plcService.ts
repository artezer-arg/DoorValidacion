import type {PlcConfig,Sequence} from './types.js';
export interface PlcDriver {handshake(step:1|2|3,sequence:Sequence,signal:AbortSignal):Promise<boolean>;}
export class PlcTimeout extends Error {}
export class PlcService {
 constructor(private real?:PlcDriver){}
 async handshake(step:1|2|3,sequence:Sequence,config:PlcConfig,forceFail:boolean){
 const controller=new AbortController();let timer:ReturnType<typeof setTimeout>|undefined;
 try {return await Promise.race([
 new Promise<boolean>((resolve,reject)=>{timer=setTimeout(()=>{controller.abort();reject(new PlcTimeout('PLC sin respuesta'));},config.timeoutMs);}),
 config.mode==='REAL'?(this.real?this.real.handshake(step,sequence,controller.signal):Promise.reject(new Error('Driver EtherNet/IP no configurado; operación bloqueada'))):new Promise<boolean>(resolve=>{
 if(config.behavior==='TIMEOUT')return;
 const t=setTimeout(()=>resolve(!forceFail&&config.behavior==='OK'),config.latencyMs);controller.signal.addEventListener('abort',()=>clearTimeout(t),{once:true});
 })]);}finally{if(timer)clearTimeout(timer);controller.abort();}
 }
}
/** El módulo PLC_DRIVER debe exportar default: PlcDriver e implementar EtherNet/IP y correlación/ACK por ciclo. */
export async function loadRealDriver():Promise<PlcDriver|undefined>{
 if(!process.env.PLC_DRIVER)return undefined;
 const module=await import(process.env.PLC_DRIVER);const driver:PlcDriver=module.default;
 if(!driver||typeof driver.handshake!=='function')throw new Error('Contrato PlcDriver inválido');return driver;
}
