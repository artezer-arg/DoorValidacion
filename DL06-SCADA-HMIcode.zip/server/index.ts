import {panelDestination} from './dollyLayout.js';
import {DatabaseConfigError} from './databaseConfig.js';
import {SqlServerSource} from './sqlServerSource.js';
import {SourceValidationError} from './sourcePlanner.js';
import express from 'express';
import {createServer} from 'node:http';
import {Server} from 'socket.io';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {openDb} from './db.js';
import {PlcService,loadRealDriver} from './plcService.js';
import {PrinterService} from './printerService.js';
import {FsmService} from './fsmService.js';
const version=JSON.parse(readFileSync(resolve('package.json'),'utf8')).version as string;
const source=new SqlServerSource();
const app=express(),http=createServer(app),io=new Server(http,{maxHttpBufferSize:4096});
const db=openDb(),fsm=new FsmService(db,new PlcService(await loadRealDriver()),new PrinterService(),state=>io.emit('state-change',state));
app.disable('x-powered-by');app.use(express.json({limit:'8kb'}));
app.get('/api/health',(_req,res)=>res.json({ok:true,station:'DL06',version}));
app.get('/api/state',(_req,res)=>res.json(fsm.state()));
app.get('/api/traceability',(_req,res)=>res.json(db.prepare('SELECT sets.*, sequences.sequence_number, sequences.load_index FROM sets JOIN sequences ON sequences.id=sets.sequence_id ORDER BY sets.id').all()));
app.get('/api/source/status',(_req,res)=>res.json({configured:source.configured(),database:source.settings.public().database,station:'DL06',mode:fsm.state().source.mode,version,sourceDate:fsm.state().source.date}));
app.get('/api/source/programs',async(_req,res)=>{res.setHeader('Cache-Control','no-store');try{res.json({programs:await source.programs()});}catch(e){res.status(503).json({error:source.configured()?'No se pudo consultar Orden_Produccion. Revisar conexión, base y permiso SELECT.':'Configurar la conexión a SQL Server en Base de datos.'});}});
app.post('/api/source/preview',async(req,res)=>{try{res.json(await source.preview(req.body).then(plan=>({...plan,vehicles:plan.vehicles.map(v=>({...v,panels:v.panels.map(p=>({...p,...panelDestination(v.loadIndex,p.position,p.hand,fsm.layout())}))}))})));}catch(e){res.status(e instanceof SourceValidationError?400:503).json({error:e instanceof SourceValidationError?e.message:source.configured()?'No se pudo leer SQL Server. Verificar conexión y permisos SELECT.':'Configurar MSSQL_SERVER, MSSQL_USER y MSSQL_PASSWORD en el servidor del puesto'});}});
const localConfigAccess:express.RequestHandler=(req,res,next)=>{
 const ip=req.socket.remoteAddress;
 if(!['127.0.0.1','::1','::ffff:127.0.0.1'].includes(ip??'')){res.status(403).json({error:'Configurar la DB desde el navegador del equipo del puesto (localhost)'});return;}
 res.setHeader('Cache-Control','no-store');
 const host=req.get('host');try{if(!['localhost','127.0.0.1','[::1]'].includes(new URL('http://'+host).hostname)){res.status(403).json({error:'Abrir la configuración desde http://localhost:3002'});return;}}catch{res.status(403).json({error:'Host inválido'});return;}
 const origin=req.get('origin');
 if(origin){try{if(new URL(origin).origin!==req.protocol+'://'+host){res.status(403).json({error:'Origen no permitido'});return;}}catch{res.status(403).json({error:'Origen inválido'});return;}}
 if(req.method==='POST'&&!req.is('application/json')){res.status(415).json({error:'Enviar configuración JSON'});return;}
 next();
};
app.post('/api/qr-config',localConfigAccess,(req,res)=>{try{fsm.configureQr(req.body);res.json(fsm.state());}catch(e){res.status(409).json({error:e instanceof Error?e.message:'Configuración QR inválida'});}});
app.post('/api/qr-config/test',localConfigAccess,(req,res)=>{try{res.json({ok:true,...fsm.testQr(req.body)});}catch(e){res.status(400).json({error:e instanceof Error?e.message:'QR inválido'});}});
app.post('/api/station',localConfigAccess,(req,res)=>{try{fsm.configureStation(req.body);res.json(fsm.state());}catch(e){res.status(409).json({error:e instanceof Error?e.message:'Configuración inválida'});}});
app.get('/api/station/progress',(req,res)=>{res.setHeader('Cache-Control','no-store');const cfg=fsm.station();if(!cfg.peerUrl||!cfg.token||req.get('X-DL06-Token')!==cfg.token){res.sendStatus(403);return;}res.json(fsm.snapshot());});
app.post('/api/dolly-layout',localConfigAccess,(req,res)=>{try{fsm.configureLayout(req.body);res.json(fsm.state());}catch(e){res.status(409).json({error:e instanceof Error?e.message:'Distribución inválida'});}});
app.get('/api/database-config',localConfigAccess,(_req,res)=>res.json(source.settings.public()));
app.post('/api/database-config/test',localConfigAccess,async(req,res)=>{try{res.json(await source.testSettings(req.body));}catch(e){res.status(e instanceof DatabaseConfigError?400:503).json({error:e instanceof DatabaseConfigError?e.message:'No se pudo conectar o leer las tablas. Revisar servidor/instancia, puerto, base, usuario, contraseña y certificado.'});}});
app.post('/api/database-config',localConfigAccess,async(req,res)=>{try{res.json({ok:true,config:await source.saveSettings(req.body),message:'Configuración guardada y aplicada. No requiere reiniciar.'});}catch(e){res.status(e instanceof DatabaseConfigError?400:500).json({error:e instanceof DatabaseConfigError?e.message:'No se pudo guardar la configuración en el equipo del puesto'});}});
app.post('/api/source/refresh',localConfigAccess,async(_req,res)=>{await fsm.updateSource(s=>source.preview(s));res.json(fsm.state());});
app.post('/api/source/load',localConfigAccess,async(req,res)=>{try{await fsm.loadSource(()=>source.preview(req.body),Number(req.body.requiredCuringMinutes??60),req.body.replaceActive===true);res.json(fsm.state());}catch(e){res.status(e instanceof SourceValidationError?400:409).json({error:e instanceof Error?e.message:'No se pudo cargar SQL Server'});}});
app.use(express.static(resolve('public'),{setHeaders:res=>res.setHeader('Cache-Control','no-cache')}));
app.get('*',(_req,res)=>res.sendFile(resolve('public/index.html')));
io.on('connection',socket=>{
 socket.emit('state-change',fsm.state());
 const guard=(fn:()=>unknown)=>{try{const result=fn();if(result instanceof Promise)result.catch(e=>socket.emit('command-error',String(e)));}catch(e){socket.emit('command-error',String(e));}};
 socket.on('scan',data=>guard(async()=>{await fsm.refreshPeer();if(source.configured()&&fsm.state().source.mode==='DEMO')throw new Error('SQL configurado, pero el programa no está cargado. Seleccionar una fecha disponible y Cargar secuencias para escanear.');return fsm.scan(data?.barcode,data?.operatorId);}));
 socket.on('dismiss-error',()=>guard(()=>fsm.dismissError()));
 socket.on('plc-config',data=>guard(()=>fsm.configure(data??{})));
 socket.on('set-sequence-range',data=>guard(()=>fsm.setSequenceRange(data?.start,data?.end)));
 socket.on('reset-demo',()=>guard(()=>fsm.reset()));
 socket.on('retry-print',()=>guard(()=>fsm.retryPrint()));
});
await fsm.recover();
http.on('error',error=>{console.error('No se pudo iniciar DL06:',error.message,'Cerrar el servidor anterior antes de abrir esta versión.');process.exit(1);});
let updating=false;const sourceTimer=setInterval(async()=>{if(updating)return;updating=true;try{await fsm.updateSource(s=>source.preview(s));}finally{updating=false;}},5000);
let syncing=false;const syncTimer=setInterval(async()=>{if(syncing||!fsm.station().peerUrl)return;syncing=true;try{await fsm.refreshPeer();await fsm.syncPrintJobs();}catch{}finally{syncing=false;}},2000);
http.listen(Number(process.env.PORT??3002),process.env.HOST??'0.0.0.0',()=>console.log('DL06 http://localhost:3002'));
function shutdown(){clearInterval(syncTimer);clearInterval(sourceTimer);void source.close();io.close();http.close(()=>{db.close();process.exit(0);});}process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
