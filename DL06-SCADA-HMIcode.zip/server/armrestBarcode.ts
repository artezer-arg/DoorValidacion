export interface ArmrestBarcode {sd:string;position:'FR'|'RR';hand:'LH'|'RH';bondedAt:string;curingMinutes:number;}
/** Plant clock is Argentina UTC-03:00; do not depend on the server OS timezone. */
export function parseArmrestBarcode(barcode:string,now=Date.now()):ArmrestBarcode {
 const match=/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(A[A-Z0-9]{2})(FR|RR)(LH|RH)$/.exec(barcode);
 if(!match)throw new Error('Formato armrest inválido: yyyyMMddHHmmss + SD + FR/RR + LH/RH');
 const [,year,month,day,hour,minute,second,sd,position,hand]=match;
 return {...parseBondedAt(year+month+day+hour+minute+second,now),sd,position:position as 'FR'|'RR',hand:hand as 'LH'|'RH'};
}
export function parseBondedAt(value:string,now=Date.now()){
 const match=/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/.exec(value);if(!match)throw new Error('Fecha armrest: usar yyyyMMddHHmmss');
 const [,year,month,day,hour,minute,second]=match;
 const local=`${year}-${month}-${day}T${hour}:${minute}:${second}`;
 const date=new Date(local+'-03:00');
 const expected=Date.UTC(Number(year),Number(month)-1,Number(day),Number(hour),Number(minute),Number(second));
 if(Number(year)<2000||Number(month)<1||Number(month)>12||Number(day)<1||Number(day)>31||Number(hour)>23||Number(minute)>59||Number(second)>59||!Number.isFinite(date.getTime())||new Date(expected).toISOString().slice(0,19)!==local)throw new Error('Fecha/hora armrest inválida');
 if(date.getTime()>now)throw new Error('Fecha de encolado futura');
 return {bondedAt:date.toISOString(),curingMinutes:(now-date.getTime())/60000};
}
export function formatArmrestBarcode(sd:string,position:string,hand:string,bondedAt=Date.now()-99*60000){
 return new Date(bondedAt-3*3600000).toISOString().slice(0,19).replace(/\D/g,'')+sd+position+hand;
}
