import {Socket} from 'node:net';
import {mkdir,writeFile} from 'node:fs/promises';
export class PrinterService {
 readonly mode=process.env.PRINTER_MODE==='REAL'?'REAL':'SIMULATOR';
 async print(id:number,zpl:string){
 if(this.mode==='SIMULATOR'){await mkdir('print-output',{recursive:true});await writeFile(`print-output/lote-${id}.zpl`,zpl);return;}
 const host=process.env.ZEBRA_HOST;if(!host)throw new Error('Falta ZEBRA_HOST');
 await new Promise<void>((resolve,reject)=>{
 const socket=new Socket();let done=false;
 const finish=(e?:Error)=>{if(done)return;done=true;socket.destroy();e?reject(e):resolve();};
 socket.setTimeout(5000,()=>finish(new Error('Timeout Zebra TCP')));socket.on('error',finish);
 socket.connect(Number(process.env.ZEBRA_PORT??9100),host,()=>socket.end(zpl));
 socket.on('close',hadError=>{if(!hadError)finish();});
 });
 }
}
export function blockZpl(truck:string,block:number,rows:{sequence_number:number;model:string;hand:string;position:string;dolly_number:number;dolly_column:number}[]){
 const clean=(s:string)=>s.replace(/[^A-Za-z0-9 .:()/-]/g,'');
 return `^XA^CI28^PW812^LL${250+rows.length*40}^FO40,30^A0N,40,40^FDDL06 DESPACHO JIS^FS`+`^FO40,90^A0N,28,28^FDCAMION ${clean(truck)} / PAR ${block}^FS`+rows.map((r,i)=>`^FO40,${150+i*40}^A0N,25,25^FD${r.sequence_number} ${clean(r.model)} ${r.position} ${r.hand} D${r.dolly_number} C${r.dolly_column}^FS`).join('')+`^FO40,${180+rows.length*40}^A0N,24,24^FD6 SECUENCIAS VALIDADAS - DL06^FS^XZ`;
}
