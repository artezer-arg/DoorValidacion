export interface StationConfig {id:string;allowed:string[];peerUrl:string;token:string;printOwner:boolean;}
export interface PeerSnapshot {id:string;allowed:string[];peerUrl:string;printOwner:boolean;program:string;manifest:{id:number;key:string;signature:string}[];complete:number[];}
export function validateStation(input:unknown,previous:StationConfig):StationConfig {
 const v=input as StationConfig;
 if(!v||typeof v.id!=='string'||!/^[-\w]{1,32}$/.test(v.id))throw new Error('Identificador de puesto inválido');
 if(!Array.isArray(v.allowed)||!v.allowed.length||new Set(v.allowed).size!==v.allowed.length||v.allowed.some(k=>!['FR-RH','FR-LH','RR-RH','RR-LH'].includes(k)))throw new Error('Seleccionar posiciones y manos válidas');
 if(typeof v.peerUrl!=='string'||typeof v.printOwner!=='boolean')throw new Error('Configuración de puesto inválida');
 const peerUrl=v.peerUrl.trim().replace(/\/$/,'');
 if(peerUrl){const u=new URL(peerUrl);const parts=u.hostname.split('.').map(Number);if(u.protocol!=='http:'||u.port!=='3002'||u.username||u.password||u.pathname!=='/'||u.search||u.hash||parts.length!==4||parts.some(n=>!Number.isInteger(n)||n<0||n>255)||!(parts[0]===10||parts[0]===192&&parts[1]===168||parts[0]===172&&parts[1]>=16&&parts[1]<=31))throw new Error('Usar http://IP-privada-del-otro-puesto:3002');}
 const token=typeof v.token==='string'&&v.token?v.token:previous.token;
 if(peerUrl&&(!token||token.length<16||token.length>128))throw new Error('Usar una clave compartida de 16 a 128 caracteres');
 return {id:v.id,allowed:v.allowed,peerUrl,token,printOwner:v.printOwner};
}
