-- Discover actual dates; do not assume today contains a program.
SELECT CONVERT(char(10), Fecha_Secuencia, 23) AS date,
       COUNT(*) AS panels, COUNT(DISTINCT Secuencia) AS vehicles,
       MIN(Secuencia) AS firstSequence, MAX(Secuencia) AS lastSequence
FROM dbo.Orden_Produccion
WHERE Puesto = 'DL06' AND SD LIKE 'D%' AND Fecha_Secuencia IS NOT NULL
GROUP BY CONVERT(char(10), Fecha_Secuencia, 23)
ORDER BY date DESC;
