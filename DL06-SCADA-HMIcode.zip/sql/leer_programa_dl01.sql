-- La fecha identifica SOLO la primera secuencia del camion.
-- El resto se lee por secuencia, dentro del programa iniciado en esa orden.
DECLARE @anchor int = (
 SELECT MIN(ID_OrdenProduccion) FROM dbo.Orden_Produccion
 WHERE Puesto='DL06' AND SD LIKE 'D%' AND Secuencia=@desde
 AND Fecha_Secuencia>=@fecha AND Fecha_Secuencia<DATEADD(day,1,@fecha)
);
-- No mezclar con otro programa que vuelva a usar la secuencia inicial.
DECLARE @nextProgram int = (
 SELECT MIN(o.ID_OrdenProduccion) FROM dbo.Orden_Produccion o
 WHERE o.Puesto='DL06' AND o.SD LIKE 'D%' AND o.Secuencia=@desde
 AND o.ID_OrdenProduccion>=@anchor
 AND o.ID_OrdenCliente NOT IN (
 SELECT ID_OrdenCliente FROM dbo.Orden_Produccion
 WHERE Puesto='DL06' AND SD LIKE 'D%' AND Secuencia=@desde
 AND Fecha_Secuencia>=@fecha AND Fecha_Secuencia<DATEADD(day,1,@fecha)
 )
);
SELECT ID_OrdenProduccion AS id, ID_OrdenCliente AS clientOrderId,
 Secuencia AS sequence, CONVERT(char(10),Fecha_Secuencia,23) AS date,
 Suffix AS suffix, SD AS sd, Referencia AS reference,
 Mano AS hand, Posicion AS position, Orden AS [order]
INTO #DL06Selected
FROM dbo.Orden_Produccion
WHERE Puesto='DL06' AND SD LIKE 'D%' AND Secuencia BETWEEN @desde AND @hasta
 AND ID_OrdenProduccion>=@anchor
 AND (@nextProgram IS NULL OR ID_OrdenProduccion<@nextProgram)
 AND (Secuencia<>@desde OR (Fecha_Secuencia>=@fecha AND Fecha_Secuencia<DATEADD(day,1,@fecha)));
SELECT * FROM #DL06Selected ORDER BY sequence, [order], id;
SELECT ID_BOM AS id, Suffix AS suffix, SD AS sd FROM dbo.BOM_Suffix
WHERE Suffix IN (SELECT DISTINCT suffix FROM #DL06Selected)
ORDER BY Suffix, ID_BOM;
DROP TABLE #DL06Selected;
